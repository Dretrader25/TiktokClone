"use client"

import { useTheme } from "@/components/theme-provider"
import { Switch } from "@/components/ui/switch"

interface ThemeModeToggleProps {
  onToggle?: (checked: boolean) => void
}

export function ThemeModeToggle({ onToggle }: ThemeModeToggleProps) {
  const { theme, setTheme } = useTheme()

  const handleToggle = (checked: boolean) => {
    const newTheme = checked ? "dark" : "light"
    setTheme(newTheme)
    if (onToggle) onToggle(checked)
  }

  return (
    <Switch checked={theme === "dark"} onCheckedChange={handleToggle} className="data-[state=checked]:bg-primary" />
  )
}
