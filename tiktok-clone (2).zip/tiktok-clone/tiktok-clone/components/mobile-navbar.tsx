"use client"

import type React from "react"

import { Home, Plus, Search, User, MessageSquare } from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/hooks/use-auth"
import { useNotification } from "@/contexts/notification-context"

import { cn } from "@/lib/utils"

export function MobileNavbar() {
  const pathname = usePathname()
  const router = useRouter()
  const { isAuthenticated } = useAuth()
  const { showNotification } = useNotification()

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 z-50 w-full h-16 bg-background border-t border-border backdrop-blur-sm"
    >
      <div className="grid h-full grid-cols-5">
        <NavbarItem icon={<Home className="h-6 w-6" />} label="Home" href="/" isActive={pathname === "/"} />
        <NavbarItem
          icon={<Search className="h-6 w-6" />}
          label="Discover"
          href="/discover"
          isActive={pathname === "/discover"}
        />
        <NavbarItem
          icon={<Plus className="h-8 w-8" />}
          label="Create"
          href="/create"
          isCreate
          isActive={pathname === "/create"}
        />
        <NavbarItem
          icon={<MessageSquare className="h-6 w-6" />}
          label="Messages"
          href="/messages"
          isActive={pathname === "/messages" || pathname === "/messages/snaps" || pathname === "/messages/inbox"}
          hasDot={true}
        />
        <NavbarItem
          icon={<User className="h-6 w-6" />}
          label="Profile"
          href="/profile"
          isActive={pathname === "/profile"}
        />
      </div>
    </motion.div>
  )
}

interface NavbarItemProps {
  icon: React.ReactNode
  label: string
  href: string
  isActive?: boolean
  isCreate?: boolean
  hasDot?: boolean
  onClick?: (e: React.MouseEvent) => void
}

function NavbarItem({ icon, label, href, isActive, isCreate, hasDot, onClick }: NavbarItemProps) {
  return (
    <Link
      href={href}
      className={cn("flex flex-col items-center justify-center", isActive && "text-primary")}
      onClick={onClick}
    >
      <div className="relative">
        {isCreate ? (
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="flex items-center justify-center w-12 h-8 bg-gradient-to-r from-pink-500 to-violet-500 rounded-md"
          >
            {icon}
          </motion.div>
        ) : (
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            {icon}
          </motion.div>
        )}

        {hasDot && !isActive && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"
          />
        )}
      </div>
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="text-xs mt-1"
      >
        {label}
      </motion.span>
      {isActive && (
        <motion.div
          layoutId="activeTab"
          className="absolute bottom-0 w-6 h-0.5 bg-primary rounded-full"
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        />
      )}
    </Link>
  )
}
