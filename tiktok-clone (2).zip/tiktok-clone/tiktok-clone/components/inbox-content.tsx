"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Check, MoreHorizontal, Send } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { AnimatedList, AnimatedListItem, SlideUp } from "@/components/animated-components"

// Sample data for messages
const MESSAGES = [
  {
    id: "1",
    user: {
      id: "user1",
      username: "@dancequeen",
      avatar: "/diverse-woman-avatars.png",
      isVerified: true,
    },
    lastMessage: "Hey! Loved your latest video 🔥",
    timestamp: "2h ago",
    unread: true,
  },
  {
    id: "2",
    user: {
      id: "user2",
      username: "@creativecoder",
      avatar: "/diverse-avatars.png",
      isVerified: false,
    },
    lastMessage: "Can you teach me that transition?",
    timestamp: "Yesterday",
    unread: false,
  },
  {
    id: "3",
    user: {
      id: "user3",
      username: "@funnyguy",
      avatar: "/diverse-man-portrait.png",
      isVerified: true,
    },
    lastMessage: "Let's collab on a video this weekend!",
    timestamp: "2d ago",
    unread: true,
  },
  {
    id: "4",
    user: {
      id: "user4",
      username: "@musicproducer",
      avatar: "/diverse-group-city.png",
      isVerified: false,
    },
    lastMessage: "I made a beat you might like for your next video",
    timestamp: "3d ago",
    unread: false,
  },
  {
    id: "5",
    user: {
      id: "user5",
      username: "@travelblogger",
      avatar: "/contemplative-artist.png",
      isVerified: true,
    },
    lastMessage: "Where did you film that sunset video?",
    timestamp: "1w ago",
    unread: false,
  },
]

// Sample conversation data
const CONVERSATION = {
  user: MESSAGES[0].user,
  messages: [
    {
      id: "msg1",
      sender: "them",
      text: "Hey! Loved your latest video 🔥",
      timestamp: "2:30 PM",
    },
    {
      id: "msg2",
      sender: "me",
      text: "Thanks so much! I worked really hard on it",
      timestamp: "2:32 PM",
    },
    {
      id: "msg3",
      sender: "them",
      text: "The transitions were so smooth. What app do you use to edit?",
      timestamp: "2:33 PM",
    },
    {
      id: "msg4",
      sender: "me",
      text: "I use CapCut for most of my edits. It's pretty easy to use!",
      timestamp: "2:36 PM",
    },
    {
      id: "msg5",
      sender: "them",
      text: "Cool! I'll have to try it out. Would you be interested in doing a collab sometime?",
      timestamp: "2:40 PM",
    },
  ],
}

export default function InboxContent() {
  const [activeTab, setActiveTab] = useState("messages")
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [newMessage, setNewMessage] = useState("")
  const [conversations, setConversations] = useState(MESSAGES)
  const [sentMessages, setSentMessages] = useState<string[]>([])

  // Mark message as read when selected
  const handleSelectConversation = (id: string) => {
    setSelectedConversation(id)
    setConversations(conversations.map((convo) => (convo.id === id ? { ...convo, unread: false } : convo)))
  }

  // Handle sending a new message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    // In a real app, you would send this to your backend
    console.log("Sending message:", newMessage)

    // Add to sent messages for animation
    setSentMessages([...sentMessages, newMessage])

    // Clear the input
    setNewMessage("")
  }

  // Handle marking all as read
  const markAllAsRead = () => {
    setConversations(conversations.map((convo) => ({ ...convo, unread: false })))
  }

  return (
    <div className="max-w-lg mx-auto">
      <AnimatePresence mode="wait">
        {selectedConversation ? (
          // Conversation view
          <motion.div
            key="conversation"
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ type: "spring", damping: 25, stiffness: 120 }}
            className="flex flex-col h-[calc(100vh-128px)]"
          >
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="flex items-center p-4 border-b border-zinc-800"
            >
              <Button variant="ghost" size="icon" onClick={() => setSelectedConversation(null)}>
                <ArrowLeft className="h-5 w-5" />
              </Button>

              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="flex items-center ml-2"
              >
                <Avatar className="h-8 w-8 mr-2">
                  <AvatarImage src={CONVERSATION.user.avatar || "/placeholder.svg"} alt={CONVERSATION.user.username} />
                  <AvatarFallback>{CONVERSATION.user.username[1]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold flex items-center">
                    {CONVERSATION.user.username}
                    {CONVERSATION.user.isVerified && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.2, type: "spring" }}
                        className="ml-1 text-blue-400"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="w-4 h-4"
                        >
                          <path
                            fillRule="evenodd"
                            d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </motion.span>
                    )}
                  </div>
                </div>
              </motion.div>

              <Button variant="ghost" size="icon" className="ml-auto">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </motion.div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <AnimatedList>
                {CONVERSATION.messages.map((message, index) => (
                  <AnimatedListItem key={message.id}>
                    <motion.div
                      initial={{ opacity: 0, y: 20, scale: 0.9 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className={cn(
                        "max-w-[80%] rounded-2xl p-3",
                        message.sender === "me"
                          ? "bg-primary text-white ml-auto rounded-br-none"
                          : "bg-zinc-800 rounded-bl-none",
                      )}
                    >
                      <p>{message.text}</p>
                      <p className="text-xs opacity-70 mt-1 text-right">{message.timestamp}</p>
                    </motion.div>
                  </AnimatedListItem>
                ))}
                {sentMessages.map((text, index) => (
                  <motion.div
                    key={`sent-${index}`}
                    initial={{ opacity: 0, y: 20, scale: 0.9 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className="max-w-[80%] rounded-2xl p-3 bg-primary text-white ml-auto rounded-br-none"
                  >
                    <p>{text}</p>
                    <p className="text-xs opacity-70 mt-1 text-right">Just now</p>
                  </motion.div>
                ))}
              </AnimatedList>
            </div>

            <motion.form
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              onSubmit={handleSendMessage}
              className="p-4 border-t border-zinc-800 flex gap-2"
            >
              <Input
                className="bg-zinc-800 border-zinc-700"
                placeholder="Send a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                type="submit"
                className="rounded-full bg-primary p-2 flex items-center justify-center"
              >
                <Send className="h-5 w-5" />
              </motion.button>
            </motion.form>
          </motion.div>
        ) : (
          // Inbox view
          <motion.div key="inbox" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="flex items-center justify-between p-4 border-b border-zinc-800">
              {conversations.some((msg) => msg.unread) && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={markAllAsRead}
                  className="flex items-center text-sm text-zinc-400 hover:text-white ml-auto"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Mark all as read
                </motion.button>
              )}
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full bg-zinc-900 rounded-none border-b border-zinc-800">
                <TabsTrigger value="messages" className="flex-1">
                  <motion.span layoutId="tabContent">Messages</motion.span>
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex-1">
                  <motion.span layoutId="tabContent">Notifications</motion.span>
                </TabsTrigger>
                <TabsTrigger value="system" className="flex-1">
                  <motion.span layoutId="tabContent">System</motion.span>
                </TabsTrigger>
              </TabsList>

              <AnimatePresence mode="wait">
                <TabsContent value="messages" className="mt-0">
                  <AnimatedList>
                    {conversations.map((message) => (
                      <AnimatedListItem key={message.id}>
                        <motion.div
                          whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                          className={cn("flex items-center p-4 cursor-pointer", message.unread && "bg-zinc-900/50")}
                          onClick={() => handleSelectConversation(message.id)}
                        >
                          <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
                            <Avatar className="h-12 w-12 mr-3">
                              <AvatarImage
                                src={message.user.avatar || "/placeholder.svg"}
                                alt={message.user.username}
                              />
                              <AvatarFallback>{message.user.username[1]}</AvatarFallback>
                            </Avatar>
                          </motion.div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center">
                              <span className="font-semibold flex items-center">
                                {message.user.username}
                                {message.user.isVerified && (
                                  <motion.span
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    transition={{ delay: 0.2, type: "spring" }}
                                    className="ml-1 text-blue-400"
                                  >
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      viewBox="0 0 24 24"
                                      fill="currentColor"
                                      className="w-4 h-4"
                                    >
                                      <path
                                        fillRule="evenodd"
                                        d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                                        clipRule="evenodd"
                                      />
                                    </svg>
                                  </motion.span>
                                )}
                              </span>
                              <span className="ml-auto text-xs text-zinc-400">{message.timestamp}</span>
                            </div>
                            <p className={cn("text-sm truncate", message.unread ? "font-medium" : "text-zinc-400")}>
                              {message.lastMessage}
                            </p>
                          </div>

                          {message.unread && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="ml-2 h-2 w-2 rounded-full bg-primary"
                            ></motion.div>
                          )}
                        </motion.div>
                      </AnimatedListItem>
                    ))}
                  </AnimatedList>
                </TabsContent>

                <TabsContent value="notifications" className="mt-0">
                  <SlideUp>
                    <div className="p-8 text-center text-zinc-400">
                      <p>No new notifications</p>
                    </div>
                  </SlideUp>
                </TabsContent>

                <TabsContent value="system" className="mt-0">
                  <SlideUp>
                    <div className="p-8 text-center text-zinc-400">
                      <p>No system messages</p>
                    </div>
                  </SlideUp>
                </TabsContent>
              </AnimatePresence>
            </Tabs>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
