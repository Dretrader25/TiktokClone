"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { MapPin, Users, Video, Calendar, Compass } from "lucide-react"
import { useLocation } from "@/hooks/use-location"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SlideUp } from "@/components/animated-components"
import { LocationPrivacyModal } from "@/components/location-privacy-modal"

// Mock data for nearby content
const NEARBY_USERS = [
  { id: "1", username: "@localcreator", avatar: "/diverse-avatars.png", distance: "0.5 miles away" },
  { id: "2", username: "@cityvlogger", avatar: "/diverse-woman-avatars.png", distance: "0.8 miles away" },
  { id: "3", username: "@streetartist", avatar: "/diverse-man-portrait.png", distance: "1.2 miles away" },
  { id: "4", username: "@foodieexplorer", avatar: "/diverse-group-city.png", distance: "1.5 miles away" },
]

const NEARBY_VIDEOS = [
  { id: "1", thumbnail: "/cozy-corner-cafe.png", views: "15K", location: "Downtown Cafe" },
  { id: "2", thumbnail: "/urban-oasis.png", views: "8.2K", location: "Central Park" },
  { id: "3", thumbnail: "/vibrant-city-busker.png", views: "23K", location: "Main Street" },
  { id: "4", thumbnail: "/bustling-market-day.png", views: "12K", location: "Farmers Market" },
]

const LOCAL_EVENTS = [
  { id: "1", name: "Street Dance Competition", date: "Tomorrow, 3 PM", location: "City Square" },
  { id: "2", name: "Food Festival", date: "This Weekend", location: "Riverside Park" },
  { id: "3", name: "Art Exhibition", date: "Next Week", location: "Community Center" },
]

export default function NearbyContent() {
  const { status, location, isLoading, error, requestPermission } = useLocation()
  const [activeTab, setActiveTab] = useState("people")
  const [locationName, setLocationName] = useState<string | null>(null)
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)

  // Fetch location name when coordinates change
  useEffect(() => {
    if (location) {
      // In a real app, you would use a reverse geocoding service
      // For this demo, we'll simulate fetching the location name
      const fetchLocationName = async () => {
        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setLocationName("San Francisco, CA")
      }

      fetchLocationName()
    }
  }, [location])

  const handleRequestLocation = () => {
    if (status === "prompt") {
      setShowPrivacyModal(true)
    } else {
      requestPermission()
    }
  }

  const handleAcceptPrivacy = () => {
    setShowPrivacyModal(false)
    requestPermission()
  }

  const handleDeclinePrivacy = () => {
    setShowPrivacyModal(false)
  }

  if (status === "prompt" || status === "denied" || status === "unavailable") {
    return (
      <div className="flex flex-col items-center justify-center py-8 px-4">
        <div className="w-16 h-16 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
          <MapPin className="h-8 w-8 text-primary" />
        </div>

        <h3 className="text-lg font-bold mb-2">
          {status === "prompt"
            ? "Enable Location"
            : status === "denied"
              ? "Location Access Denied"
              : "Location Unavailable"}
        </h3>

        <p className="text-center text-zinc-400 mb-6 max-w-xs">
          {status === "prompt"
            ? "Allow location access to see videos and creators near you"
            : status === "denied"
              ? "Please enable location access in your browser settings to see nearby content"
              : "Location services are not available on your device or browser"}
        </p>

        {status === "prompt" && (
          <Button onClick={handleRequestLocation} disabled={isLoading} className="bg-primary hover:bg-primary/90 mb-4">
            {isLoading ? "Requesting..." : "Enable Location"}
          </Button>
        )}

        {status === "denied" && (
          <div className="space-y-4 w-full max-w-xs">
            <Button onClick={requestPermission} className="w-full bg-primary hover:bg-primary/90">
              Try Again
            </Button>
            <div className="bg-zinc-800 p-4 rounded-lg text-sm">
              <p className="font-medium mb-2">How to enable location:</p>
              <ol className="list-decimal pl-5 space-y-1 text-zinc-300">
                <li>Open your browser settings</li>
                <li>Go to Privacy & Security</li>
                <li>Find Site Settings or Location</li>
                <li>Allow this site to access your location</li>
              </ol>
            </div>
          </div>
        )}

        {error && <p className="mt-4 text-red-400 text-sm text-center">{error}</p>}

        <LocationPrivacyModal
          isOpen={showPrivacyModal}
          onClose={() => setShowPrivacyModal(false)}
          onAccept={handleAcceptPrivacy}
          onDecline={handleDeclinePrivacy}
        />
      </div>
    )
  }

  if (isLoading || !location) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <div className="w-16 h-16 rounded-full bg-zinc-800 flex items-center justify-center mb-4 relative">
          <MapPin className="h-8 w-8 text-primary" />
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-primary"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          />
        </div>
        <h3 className="text-lg font-bold mb-2">Finding your location...</h3>
        <p className="text-center text-zinc-400">This may take a moment</p>
      </div>
    )
  }

  return (
    <div className="pb-4">
      <div className="bg-zinc-900 rounded-lg p-4 mb-6 flex items-center">
        <div className="bg-zinc-800 p-2 rounded-full mr-3">
          <MapPin className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="text-sm text-zinc-400">Your location</p>
          <p className="font-medium">{locationName || "Loading location..."}</p>
        </div>
        <Button variant="ghost" size="sm" className="ml-auto text-xs" onClick={requestPermission}>
          <Compass className="h-4 w-4 mr-1" />
          Update
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full bg-zinc-900 mb-4">
          <TabsTrigger value="people" className="flex-1">
            <div className="flex items-center justify-center">
              <Users className="h-4 w-4 mr-2" />
              <span>People</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex-1">
            <div className="flex items-center justify-center">
              <Video className="h-4 w-4 mr-2" />
              <span>Videos</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="events" className="flex-1">
            <div className="flex items-center justify-center">
              <Calendar className="h-4 w-4 mr-2" />
              <span>Events</span>
            </div>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="people" className="mt-0">
          <SlideUp>
            <div className="space-y-3">
              {NEARBY_USERS.map((user) => (
                <motion.div
                  key={user.id}
                  whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                  className="flex items-center p-3 rounded-lg cursor-pointer"
                >
                  <div className="h-12 w-12 rounded-full overflow-hidden mr-3">
                    <img
                      src={user.avatar || "/placeholder.svg"}
                      alt={user.username}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{user.username}</p>
                    <p className="text-xs text-zinc-400">{user.distance}</p>
                  </div>
                  <Button size="sm" variant="outline" className="text-xs h-8">
                    Follow
                  </Button>
                </motion.div>
              ))}
            </div>
          </SlideUp>
        </TabsContent>

        <TabsContent value="videos" className="mt-0">
          <SlideUp>
            <div className="grid grid-cols-2 gap-3">
              {NEARBY_VIDEOS.map((video) => (
                <motion.div
                  key={video.id}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="relative cursor-pointer"
                >
                  <div className="aspect-[3/4] rounded-md overflow-hidden">
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt="Nearby video"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/60 px-2 py-1 rounded text-xs">
                    {video.views} views
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 rounded-b-md">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 text-primary mr-1" />
                      <p className="text-xs font-medium truncate">{video.location}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </SlideUp>
        </TabsContent>

        <TabsContent value="events" className="mt-0">
          <SlideUp>
            <div className="space-y-3">
              {LOCAL_EVENTS.map((event) => (
                <motion.div
                  key={event.id}
                  whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                  className="p-4 rounded-lg cursor-pointer border border-zinc-800"
                >
                  <h4 className="font-medium mb-1">{event.name}</h4>
                  <div className="flex items-center text-xs text-zinc-400 mb-2">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center text-xs text-zinc-400">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{event.location}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </SlideUp>
        </TabsContent>
      </Tabs>

      <div className="mt-6 bg-zinc-900 rounded-lg p-4">
        <h3 className="font-medium mb-2 flex items-center">
          <Compass className="h-4 w-4 mr-2 text-primary" />
          Explore More Nearby
        </h3>
        <p className="text-sm text-zinc-400 mb-3">Discover trending challenges and hashtags in your area</p>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {["#localfood", "#cityadventures", "#streetstyle", "#localartist", "#neighborhoodvibes"].map((tag) => (
            <motion.div
              key={tag}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-3 py-1.5 bg-zinc-800 rounded-full text-sm whitespace-nowrap"
            >
              {tag}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
