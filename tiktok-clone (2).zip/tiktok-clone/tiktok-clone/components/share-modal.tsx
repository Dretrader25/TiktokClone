"use client"

import { motion, AnimatePresence } from "framer-motion"
import { X, Copy, Facebook, Twitter, PhoneIcon as WhatsApp, Mail, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNotification } from "@/contexts/notification-context"

interface ShareModalProps {
  isOpen: boolean
  onClose: () => void
  videoId: string
}

export function ShareModal({ isOpen, onClose, videoId }: ShareModalProps) {
  const { showNotification } = useNotification()

  const shareOptions = [
    {
      name: "Copy Link",
      icon: <Copy className="h-5 w-5" />,
      color: "bg-zinc-700",
      action: () => {
        const url = `${window.location.origin}/video/${videoId}`
        navigator.clipboard
          .writeText(url)
          .then(() => {
            showNotification("success", "Link copied to clipboard")
            onClose()
          })
          .catch(() => {
            showNotification("error", "Failed to copy link")
          })
      },
    },
    {
      name: "Facebook",
      icon: <Facebook className="h-5 w-5" />,
      color: "bg-blue-600",
      action: () => {
        const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`${window.location.origin}/video/${videoId}`)}`
        window.open(url, "_blank")
        onClose()
      },
    },
    {
      name: "Twitter",
      icon: <Twitter className="h-5 w-5" />,
      color: "bg-sky-500",
      action: () => {
        const url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(`${window.location.origin}/video/${videoId}`)}&text=Check out this video!`
        window.open(url, "_blank")
        onClose()
      },
    },
    {
      name: "WhatsApp",
      icon: <WhatsApp className="h-5 w-5" />,
      color: "bg-green-500",
      action: () => {
        const url = `https://wa.me/?text=${encodeURIComponent(`Check out this video! ${window.location.origin}/video/${videoId}`)}`
        window.open(url, "_blank")
        onClose()
      },
    },
    {
      name: "Email",
      icon: <Mail className="h-5 w-5" />,
      color: "bg-red-500",
      action: () => {
        const url = `mailto:?subject=Check out this video!&body=${encodeURIComponent(`${window.location.origin}/video/${videoId}`)}`
        window.location.href = url
        onClose()
      },
    },
    {
      name: "Messages",
      icon: <MessageCircle className="h-5 w-5" />,
      color: "bg-purple-500",
      action: () => {
        const url = `sms:?&body=${encodeURIComponent(`Check out this video! ${window.location.origin}/video/${videoId}`)}`
        window.location.href = url
        onClose()
      },
    },
  ]

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 bg-card/95 backdrop-blur-md rounded-t-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-lg font-semibold">Share to</h2>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="p-4">
              <div className="grid grid-cols-4 gap-4">
                {shareOptions.map((option) => (
                  <motion.button
                    key={option.name}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex flex-col items-center gap-2"
                    onClick={option.action}
                  >
                    <div className={`w-14 h-14 rounded-full ${option.color} flex items-center justify-center`}>
                      {option.icon}
                    </div>
                    <span className="text-xs">{option.name}</span>
                  </motion.button>
                ))}
              </div>

              <div className="mt-6 mb-2">
                <div className="relative flex items-center">
                  <div className="flex-grow border-t border-border"></div>
                  <span className="flex-shrink mx-4 text-muted-foreground text-sm">or copy link</span>
                  <div className="flex-grow border-t border-border"></div>
                </div>
              </div>

              <div className="flex items-center mt-4 bg-muted rounded-lg p-2">
                <div className="flex-1 truncate px-2 text-sm">{`${window.location.origin}/video/${videoId}`}</div>
                <Button
                  size="sm"
                  onClick={() => {
                    navigator.clipboard
                      .writeText(`${window.location.origin}/video/${videoId}`)
                      .then(() => showNotification("success", "Link copied to clipboard"))
                      .catch(() => showNotification("error", "Failed to copy link"))
                  }}
                >
                  Copy
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
