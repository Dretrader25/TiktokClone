"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Shield, MapPin, Eye, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"

interface LocationPrivacyModalProps {
  isOpen: boolean
  onClose: () => void
  onAccept: () => void
  onDecline: () => void
}

export function LocationPrivacyModal({ isOpen, onClose, onAccept, onDecline }: LocationPrivacyModalProps) {
  const [step, setStep] = useState(1)

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1)
    } else {
      onAccept()
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    } else {
      onDecline()
    }
  }

  const handleClose = () => {
    setStep(1)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={handleClose}
          />

          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-4 bottom-4 top-auto bg-zinc-900 rounded-xl p-5 z-50 max-w-lg mx-auto"
          >
            <Button variant="ghost" size="icon" className="absolute right-2 top-2 rounded-full" onClick={handleClose}>
              <X className="h-5 w-5" />
            </Button>

            <div className="flex justify-center mb-4">
              <div className="flex items-center space-x-1">
                {[1, 2, 3].map((i) => (
                  <motion.div
                    key={i}
                    className={`h-1.5 rounded-full ${i === step ? "w-6 bg-primary" : "w-3 bg-zinc-700"}`}
                    animate={{ width: i === step ? 24 : 12 }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                ))}
              </div>
            </div>

            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                      <MapPin className="h-8 w-8 text-primary" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-center mb-2">Location Services</h3>
                  <p className="text-center text-zinc-400 mb-6">
                    We use your location to show you content, creators, and events near you.
                  </p>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-start">
                      <div className="bg-zinc-800 p-2 rounded-full mr-3">
                        <MapPin className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Discover nearby content</p>
                        <p className="text-xs text-zinc-400">See videos and creators in your area</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-zinc-800 p-2 rounded-full mr-3">
                        <Eye className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Find local events</p>
                        <p className="text-xs text-zinc-400">Discover trending events happening near you</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                      <Shield className="h-8 w-8 text-primary" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-center mb-2">Your Privacy Matters</h3>
                  <p className="text-center text-zinc-400 mb-6">
                    We take your privacy seriously and protect your location data.
                  </p>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-start">
                      <div className="bg-zinc-800 p-2 rounded-full mr-3">
                        <Lock className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Your data is secure</p>
                        <p className="text-xs text-zinc-400">We encrypt your location information</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-zinc-800 p-2 rounded-full mr-3">
                        <Eye className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">You're in control</p>
                        <p className="text-xs text-zinc-400">You can disable location access at any time</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                      <MapPin className="h-8 w-8 text-primary" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-center mb-2">Ready to Explore?</h3>
                  <p className="text-center text-zinc-400 mb-6">
                    Your browser will ask for permission to access your location.
                  </p>

                  <div className="bg-zinc-800 p-4 rounded-lg mb-6">
                    <p className="text-sm text-zinc-300">
                      By enabling location services, you agree to our privacy policy and terms of service regarding the
                      use of your location data.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={handleBack}>
                {step === 1 ? "Decline" : "Back"}
              </Button>
              <Button className="flex-1 bg-primary hover:bg-primary/90" onClick={handleNext}>
                {step === 3 ? "Enable Location" : "Next"}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
