"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Info } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useState, useEffect } from "react"

export function DemoIndicator() {
  const { isDemoUser } = useAuth()
  const [isVisible, setIsVisible] = useState(true)
  const [isMinimized, setIsMinimized] = useState(false)

  // Auto-hide after 10 seconds
  useEffect(() => {
    if (isDemoUser && isVisible && !isMinimized) {
      const timer = setTimeout(() => {
        setIsMinimized(true)
      }, 10000)

      return () => clearTimeout(timer)
    }
  }, [isDemoUser, isVisible, isMinimized])

  if (!isDemoUser) return null

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-20 left-0 right-0 z-40 flex justify-center px-4"
        >
          <motion.div
            layout
            className={`bg-primary/90 text-white rounded-lg shadow-lg backdrop-blur-sm ${isMinimized ? "p-2" : "p-4"}`}
          >
            {isMinimized ? (
              <div className="flex items-center">
                <button onClick={() => setIsMinimized(false)} className="flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  <span className="text-xs font-medium">Demo Mode</span>
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-start gap-3">
                  <div className="bg-white/20 p-2 rounded-full">
                    <Info className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm">Demo Mode Active</h3>
                    <p className="text-xs mt-1">
                      You're using a demo account with pre-populated data. Feel free to explore all features!
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsMinimized(true)}
                      className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded"
                    >
                      Minimize
                    </button>
                    <button
                      onClick={() => setIsVisible(false)}
                      className="text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
