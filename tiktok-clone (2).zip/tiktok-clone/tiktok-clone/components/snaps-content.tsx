"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Download, Sparkles, Smile, Send, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { SlideUp } from "@/components/animated-components"

// Sample filters
const FILTERS = [
  { id: "normal", name: "Normal", color: "none" },
  { id: "sepia", name: "Retro", color: "sepia(100%)" },
  { id: "grayscale", name: "B&W", color: "grayscale(100%)" },
  { id: "saturate", name: "Vibrant", color: "saturate(200%)" },
  { id: "hue-rotate", name: "Alien", color: "hue-rotate(90deg)" },
  { id: "invert", name: "Negative", color: "invert(80%)" },
]

// Sample friends with stories
const FRIENDS = [
  { id: "1", name: "@dancequeen", avatar: "/diverse-woman-avatars.png", hasStory: true },
  { id: "2", name: "@creativecoder", avatar: "/diverse-avatars.png", hasStory: true },
  { id: "3", name: "@funnyguy", avatar: "/diverse-man-portrait.png", hasStory: false },
  { id: "4", name: "@musicproducer", avatar: "/diverse-group-city.png", hasStory: true },
  { id: "5", name: "@travelblogger", avatar: "/contemplative-artist.png", hasStory: false },
]

export default function SnapsContent() {
  const [activeTab, setActiveTab] = useState<"camera" | "stories">("camera")
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [selectedFilter, setSelectedFilter] = useState(FILTERS[0])
  const [flashMode, setFlashMode] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [cameraPermission, setCameraPermission] = useState<boolean | null>(null)
  const [cameraFacing, setCameraFacing] = useState<"user" | "environment">("environment")
  const [showEffects, setShowEffects] = useState(false)

  // Initialize camera
  useEffect(() => {
    if (activeTab !== "camera") return

    let stream: MediaStream | null = null

    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: cameraFacing },
          audio: false,
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
        }

        setCameraPermission(true)
      } catch (err) {
        console.error("Error accessing camera:", err)
        setCameraPermission(false)
      }
    }

    startCamera()

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [activeTab, cameraFacing])

  // Capture photo
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) return

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Apply flash effect
    if (flashMode) {
      document.querySelector(".flash-effect")?.classList.add("active")
      setTimeout(() => {
        document.querySelector(".flash-effect")?.classList.remove("active")
      }, 200)
    }

    // Draw video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Get image data URL
    const imageDataURL = canvas.toDataURL("image/png")
    setCapturedImage(imageDataURL)
  }

  // Switch camera
  const switchCamera = () => {
    setCameraFacing((prev) => (prev === "user" ? "environment" : "user"))
  }

  // Discard captured image
  const discardImage = () => {
    setCapturedImage(null)
  }

  // Toggle flash mode
  const toggleFlash = () => {
    setFlashMode((prev) => !prev)
  }

  return (
    <div className="relative h-full">
      {/* Flash effect overlay */}
      <div className="flash-effect absolute inset-0 bg-white opacity-0 z-50 pointer-events-none transition-opacity duration-200"></div>

      {/* Tab switcher */}
      <div className="absolute top-0 left-0 right-0 z-20 flex justify-center p-4">
        <div className="bg-black/40 backdrop-blur-md rounded-full flex p-1">
          <motion.button
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-1.5 rounded-full text-sm font-medium ${activeTab === "camera" ? "bg-white text-black" : "text-white"}`}
            onClick={() => setActiveTab("camera")}
          >
            Camera
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            className={`px-4 py-1.5 rounded-full text-sm font-medium ${activeTab === "stories" ? "bg-white text-black" : "text-white"}`}
            onClick={() => setActiveTab("stories")}
          >
            Stories
          </motion.button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === "camera" ? (
          <motion.div
            key="camera"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full relative"
          >
            {cameraPermission === false && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black z-10 p-4">
                <div className="text-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="64"
                    height="64"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-camera mx-auto mb-4 text-zinc-400"
                  >
                    <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
                    <circle cx="12" cy="13" r="3" />
                  </svg>
                  <h2 className="text-xl font-bold mb-2">Camera Access Required</h2>
                  <p className="text-zinc-400 mb-4">Please allow camera access to use this feature</p>
                  <Button onClick={() => setCameraPermission(null)}>Try Again</Button>
                </div>
              </div>
            )}

            {/* Camera view */}
            <div className="relative h-full w-full overflow-hidden">
              {!capturedImage ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="h-full w-full object-cover"
                    style={{ filter: selectedFilter.color }}
                  />
                  <canvas ref={canvasRef} className="hidden" />
                </>
              ) : (
                <div className="relative h-full">
                  <img
                    src={capturedImage || "/placeholder.svg"}
                    alt="Captured"
                    className="h-full w-full object-cover"
                    style={{ filter: selectedFilter.color }}
                  />
                </div>
              )}

              {/* Camera controls */}
              {!capturedImage ? (
                <div className="absolute bottom-8 inset-x-0 flex flex-col items-center">
                  {/* Filters row */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-6 overflow-x-auto max-w-full flex gap-3 px-4"
                  >
                    {FILTERS.map((filter) => (
                      <motion.button
                        key={filter.id}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => setSelectedFilter(filter)}
                        className={`flex flex-col items-center ${selectedFilter.id === filter.id ? "opacity-100" : "opacity-60"}`}
                      >
                        <div
                          className="w-12 h-12 rounded-full overflow-hidden border-2 border-white mb-1"
                          style={{ borderColor: selectedFilter.id === filter.id ? "#ff3b5c" : "white" }}
                        >
                          <div
                            className="w-full h-full bg-gradient-to-br from-pink-500 to-violet-500"
                            style={{ filter: filter.color }}
                          ></div>
                        </div>
                        <span className="text-xs">{filter.name}</span>
                      </motion.button>
                    ))}
                  </motion.div>

                  {/* Camera buttons */}
                  <div className="flex items-center justify-between w-full px-8">
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={toggleFlash}
                      className={`rounded-full p-3 ${flashMode ? "bg-yellow-500" : "bg-zinc-800"}`}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-zap"
                      >
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                      </svg>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={capturePhoto}
                      className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center"
                    >
                      <div className="w-14 h-14 rounded-full bg-white"></div>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={switchCamera}
                      className="rounded-full p-3 bg-zinc-800"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-refresh-cw"
                      >
                        <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
                        <path d="M21 3v5h-5" />
                        <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
                        <path d="M3 21v-5h5" />
                      </svg>
                    </motion.button>
                  </div>

                  {/* Effects button */}
                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowEffects(!showEffects)}
                    className="absolute right-4 top-4 rounded-full p-3 bg-zinc-800"
                  >
                    <Sparkles className="h-6 w-6" />
                  </motion.button>

                  {/* Effects panel */}
                  <AnimatePresence>
                    {showEffects && (
                      <motion.div
                        initial={{ opacity: 0, x: 100 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 100 }}
                        className="absolute right-4 top-16 bg-zinc-900/80 backdrop-blur-md rounded-lg p-3 w-48"
                      >
                        <h3 className="text-sm font-medium mb-2">Effects</h3>
                        <div className="grid grid-cols-3 gap-2">
                          {Array.from({ length: 9 }).map((_, i) => (
                            <motion.button
                              key={i}
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              className="aspect-square rounded-lg bg-gradient-to-br from-pink-500/20 to-violet-500/20 flex items-center justify-center"
                            >
                              <span className="text-lg">
                                {["✨", "🔥", "💯", "🎵", "🌈", "👑", "🎭", "🌟", "🎬"][i]}
                              </span>
                            </motion.button>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="absolute bottom-8 inset-x-0 flex flex-col items-center">
                  <div className="flex items-center justify-between w-full px-8">
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={discardImage}
                      className="rounded-full p-3 bg-zinc-800"
                    >
                      <X className="h-6 w-6" />
                    </motion.button>

                    <motion.button whileTap={{ scale: 0.9 }} className="rounded-full p-3 bg-zinc-800">
                      <Download className="h-6 w-6" />
                    </motion.button>

                    <motion.button whileTap={{ scale: 0.9 }} className="rounded-full p-3 bg-primary">
                      <Send className="h-6 w-6" />
                    </motion.button>
                  </div>

                  {/* Drawing tools */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 flex gap-4"
                  >
                    <motion.button whileTap={{ scale: 0.9 }} className="rounded-full p-2 bg-zinc-800">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-pencil"
                      >
                        <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                        <path d="m15 5 4 4" />
                      </svg>
                    </motion.button>
                    <motion.button whileTap={{ scale: 0.9 }} className="rounded-full p-2 bg-zinc-800">
                      <Smile className="h-5 w-5" />
                    </motion.button>
                    <motion.button whileTap={{ scale: 0.9 }} className="rounded-full p-2 bg-zinc-800">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-type"
                      >
                        <polyline points="4 7 4 4 20 4 20 7" />
                        <line x1="9" x2="15" y1="20" y2="20" />
                        <line x1="12" x2="12" y1="4" y2="20" />
                      </svg>
                    </motion.button>
                  </motion.div>
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="stories"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="h-full p-4 overflow-y-auto"
          >
            <SlideUp>
              <div className="mb-6">
                <h3 className="text-sm font-medium text-zinc-400 mb-3">Your Story</h3>
                <div className="flex items-center">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-zinc-700">
                      <img src="/diverse-avatars.png" alt="Your avatar" className="w-full h-full object-cover" />
                    </div>
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="absolute -bottom-1 -right-1 bg-primary rounded-full w-8 h-8 flex items-center justify-center border-2 border-black"
                    >
                      <Plus className="h-4 w-4" />
                    </motion.div>
                  </div>
                  <div className="ml-3">
                    <p className="font-medium">Add to Your Story</p>
                    <p className="text-xs text-zinc-400">Share a moment with friends</p>
                  </div>
                </div>
              </div>
            </SlideUp>

            <SlideUp delay={0.2}>
              <div>
                <h3 className="text-sm font-medium text-zinc-400 mb-3">Friends' Stories</h3>
                <div className="space-y-4">
                  {FRIENDS.map((friend) => (
                    <motion.div
                      key={friend.id}
                      whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                      className="flex items-center p-2 rounded-lg cursor-pointer"
                    >
                      <div
                        className={`relative ${friend.hasStory ? "ring-2 ring-primary ring-offset-2 ring-offset-black" : ""}`}
                      >
                        <div className="w-14 h-14 rounded-full overflow-hidden">
                          <img
                            src={friend.avatar || "/placeholder.svg"}
                            alt={friend.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {friend.hasStory && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1 bg-primary rounded-full w-4 h-4"
                          />
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between items-center">
                          <p className="font-medium">{friend.name}</p>
                          <p className="text-xs text-zinc-400">{friend.hasStory ? "New" : "No story"}</p>
                        </div>
                        <p className="text-xs text-zinc-400">{friend.hasStory ? "Tap to view" : "No updates"}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </SlideUp>

            <SlideUp delay={0.3}>
              <div className="mt-6">
                <h3 className="text-sm font-medium text-zinc-400 mb-3">Discover</h3>
                <div className="grid grid-cols-2 gap-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="aspect-[3/4] rounded-lg overflow-hidden relative"
                    >
                      <img
                        src={`/enchanted-forest-path.png?height=300&width=200&query=story+${i}`}
                        alt={`Discover story ${i + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                        <p className="text-sm font-medium">Trending #{i + 1}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </SlideUp>
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx global>{`
        .flash-effect {
          opacity: 0;
          transition: opacity 200ms ease-out;
        }
        .flash-effect.active {
          animation: flash 0.3s ease-out;
        }
      `}</style>
    </div>
  )
}
