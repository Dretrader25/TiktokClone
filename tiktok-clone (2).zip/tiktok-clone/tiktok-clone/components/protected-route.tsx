"use client"

import type React from "react"
import { useAuthContext } from "@/components/auth-provider"

interface ProtectedRouteProps {
  children: React.ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated } = useAuthContext()

  // The main protection is now handled by AuthProvider
  // This component is kept for backward compatibility
  return <>{children}</>
}
