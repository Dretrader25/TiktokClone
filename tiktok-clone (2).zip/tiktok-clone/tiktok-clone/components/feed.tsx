"use client"

import { useEffect, useRef, useState } from "react"
import { Heart, MessageCircle, Share2, Music2 } from "lucide-react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import VideoPlayer from "@/components/video-player"
import { AnimatedIcon, PulseAnimation } from "./animated-components"
import { CommentsModal } from "./comments-modal"
import { ShareModal } from "./share-modal"
import { useAuth } from "@/hooks/use-auth"
import { getSupabaseClient } from "@/lib/supabase-client"
import { useNotification } from "@/contexts/notification-context"

// Sample data - in a real app this would come from an API
const VIDEOS = [
  {
    id: "1",
    videoUrl: "/joyful-street-dancer.png",
    username: "@creativecoder",
    description: "Check out this cool effect! #coding #effects",
    likes: 1243,
    comments: 32,
    shares: 17,
    userAvatar: "/diverse-avatars.png",
    audio: "Original Sound - creativecoder",
    userId: "user2",
  },
  {
    id: "2",
    videoUrl: "/vibrant-street-dance.png",
    username: "@dancequeen",
    description: "New dance trend! Who's trying this? #dance #trending",
    likes: 8743,
    comments: 124,
    shares: 342,
    userAvatar: "/diverse-woman-avatars.png",
    audio: "Trending Song - Artist Name",
    userId: "user1",
  },
  {
    id: "3",
    videoUrl: "/squirrel-nut-heist.png",
    username: "@funnyguy",
    description: "When your code finally works 😂 #programming #humor",
    likes: 4532,
    comments: 87,
    shares: 56,
    userAvatar: "/diverse-man-portrait.png",
    audio: "Funny Sound Effect - meme",
    userId: "user3",
  },
]

export default function Feed() {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0)
  const [likedVideos, setLikedVideos] = useState<Record<string, boolean>>({})
  const [showCommentsModal, setShowCommentsModal] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [currentVideoId, setCurrentVideoId] = useState<string | null>(null)
  const feedRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const { user } = useAuth()
  const { showNotification } = useNotification()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const handleScroll = () => {
      if (!feedRef.current) return

      const scrollPosition = feedRef.current.scrollTop
      const videoHeight = window.innerHeight
      const index = Math.round(scrollPosition / videoHeight)

      if (index !== currentVideoIndex && index >= 0 && index < VIDEOS.length) {
        setCurrentVideoIndex(index)
      }
    }

    const feedElement = feedRef.current
    if (feedElement) {
      feedElement.addEventListener("scroll", handleScroll)
    }

    return () => {
      if (feedElement) {
        feedElement.removeEventListener("scroll", handleScroll)
      }
    }
  }, [currentVideoIndex])

  const handleLike = async (videoId: string) => {
    if (!user) {
      showNotification("info", "Sign in to like videos")
      return
    }

    try {
      // In a real app, you would update the likes in your database
      // For now, we'll just update the local state
      setLikedVideos((prev) => ({
        ...prev,
        [videoId]: !prev[videoId],
      }))

      // Show notification
      if (!likedVideos[videoId]) {
        showNotification("success", "Video added to your liked videos")
      }
    } catch (error) {
      console.error("Error liking video:", error)
      showNotification("error", "Failed to like video")
    }
  }

  const handleComment = (videoId: string) => {
    if (!user) {
      showNotification("info", "Sign in to comment on videos")
      return
    }

    setCurrentVideoId(videoId)
    setShowCommentsModal(true)
  }

  const handleShare = (videoId: string) => {
    setCurrentVideoId(videoId)
    setShowShareModal(true)
  }

  const handleProfileClick = (userId: string) => {
    // Navigate to the user's profile
    router.push(`/user/${userId}`)
  }

  return (
    <>
      <div ref={feedRef} className="h-[calc(100vh-64px)] w-full overflow-y-scroll snap-y snap-mandatory bg-background">
        {VIDEOS.map((video, index) => {
          const isActive = index === currentVideoIndex
          const isLiked = likedVideos[video.id]

          return (
            <div key={video.id} className="h-[calc(100vh-64px)] w-full snap-start snap-always relative">
              <VideoPlayer src={video.videoUrl} isActive={isActive} />

              {/* Floating music disc */}
              {isActive && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  className="absolute bottom-32 left-4 z-10 flex items-center gap-2 bg-background/30 backdrop-blur-sm rounded-full px-3 py-1.5 max-w-[60%]"
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "linear" }}
                    className="bg-white rounded-full p-1"
                  >
                    <Music2 className="h-3 w-3 text-black" />
                  </motion.div>
                  <span className="text-xs truncate">{video.audio}</span>
                </motion.div>
              )}

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: isActive ? 1 : 0, y: isActive ? 0 : 20 }}
                transition={{ duration: 0.3 }}
                className="absolute bottom-20 left-4 z-10 max-w-[80%]"
              >
                <div className="mb-2">
                  <motion.h3
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="font-bold text-lg"
                  >
                    {video.username}
                  </motion.h3>
                  <motion.p
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="text-sm"
                  >
                    {video.description}
                  </motion.p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: isActive ? 1 : 0, x: isActive ? 0 : 20 }}
                transition={{ duration: 0.3, staggerChildren: 0.1 }}
                className="absolute bottom-24 right-4 flex flex-col items-center gap-4"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="flex flex-col items-center"
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full bg-background/20 backdrop-blur-sm"
                    onClick={() => handleLike(video.id)}
                  >
                    {isLiked ? (
                      <PulseAnimation>
                        <Heart className="h-6 w-6 fill-red-500 text-red-500" />
                      </PulseAnimation>
                    ) : (
                      <AnimatedIcon>
                        <Heart className="h-6 w-6" />
                      </AnimatedIcon>
                    )}
                  </Button>
                  <motion.span
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="text-xs mt-1"
                  >
                    {isLiked ? video.likes + 1 : video.likes}
                  </motion.span>
                </motion.div>

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3, type: "spring" }}
                  className="flex flex-col items-center"
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full bg-background/20 backdrop-blur-sm"
                    onClick={() => handleComment(video.id)}
                  >
                    <AnimatedIcon>
                      <MessageCircle className="h-6 w-6" />
                    </AnimatedIcon>
                  </Button>
                  <motion.span
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="text-xs mt-1"
                  >
                    {video.comments}
                  </motion.span>
                </motion.div>

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.4, type: "spring" }}
                  className="flex flex-col items-center"
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full bg-background/20 backdrop-blur-sm"
                    onClick={() => handleShare(video.id)}
                  >
                    <AnimatedIcon>
                      <Share2 className="h-6 w-6" />
                    </AnimatedIcon>
                  </Button>
                  <motion.span
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="text-xs mt-1"
                  >
                    {video.shares}
                  </motion.span>
                </motion.div>

                <motion.div
                  initial={{ scale: 0, rotate: -30 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
                  className="h-10 w-10 rounded-full overflow-hidden border-2 border-white mt-2 cursor-pointer"
                  onClick={() => handleProfileClick(video.userId)}
                >
                  <img
                    src={video.userAvatar || "/placeholder.svg"}
                    alt={video.username}
                    className="h-full w-full object-cover"
                  />
                </motion.div>
              </motion.div>
            </div>
          )
        })}
      </div>

      {/* Comments Modal */}
      <CommentsModal
        isOpen={showCommentsModal}
        onClose={() => setShowCommentsModal(false)}
        videoId={currentVideoId || ""}
      />

      {/* Share Modal */}
      <ShareModal isOpen={showShareModal} onClose={() => setShowShareModal(false)} videoId={currentVideoId || ""} />
    </>
  )
}
