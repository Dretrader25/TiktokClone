"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { usePathname, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"

// Define public routes that don't require authentication
const PUBLIC_ROUTES = ["/login", "/register", "/forgot-password"]

// Create context for auth state
const AuthContext = createContext<{ isAuthenticated: boolean }>({
  isAuthenticated: false,
})

export const useAuthContext = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth()
  const [isChecking, setIsChecking] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Skip auth check for public routes
    if (PUBLIC_ROUTES.includes(pathname)) {
      setIsChecking(false)
      return
    }

    // Wait for auth to load
    if (!isLoading) {
      if (!isAuthenticated) {
        // Store the current path to redirect back after login
        if (typeof window !== "undefined") {
          sessionStorage.setItem("redirectAfterLogin", pathname)
        }

        // Redirect to login
        router.push("/login")
      }

      setIsChecking(false)
    }
  }, [isAuthenticated, isLoading, pathname, router])

  // Show nothing while checking auth
  if (isChecking && !PUBLIC_ROUTES.includes(pathname)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center">
          <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return <AuthContext.Provider value={{ isAuthenticated }}>{children}</AuthContext.Provider>
}
