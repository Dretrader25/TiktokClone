"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

interface VideoPlayerProps {
  src: string
  isActive: boolean
}

export default function VideoPlayer({ src, isActive }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (!videoRef.current) return

    // Only try to play if we're active and haven't encountered an error
    if (isActive && !error) {
      const playPromise = videoRef.current.play()

      // Play might not return a promise in all browsers
      if (playPromise !== undefined) {
        playPromise.catch((error) => {
          console.log("Error playing video:", error.message)
          setError(true)
        })
      }
    } else {
      videoRef.current.pause()
      if (!isActive) {
        videoRef.current.currentTime = 0
      }
    }
  }, [isActive, error])

  // Check if the src is a valid video URL
  const isValidVideoUrl = src.match(/\.(mp4|webm|ogg)$/) !== null

  return (
    <div className="h-full w-full bg-background">
      {isValidVideoUrl && !error ? (
        <video
          ref={videoRef}
          src={src}
          className="h-full w-full object-cover"
          loop
          muted
          playsInline
          poster="/abstract-thumbnail.png"
          onError={() => setError(true)}
        />
      ) : (
        // Fallback to an image when video can't be played
        <div className="relative h-full w-full">
          <Image
            src={src.includes("placeholder.svg") ? src : "/placeholder.svg?height=720&width=405&query=video+content"}
            alt="Video content"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-black/50 px-4 py-2 rounded-lg text-white text-sm">Video preview</div>
          </div>
        </div>
      )}
    </div>
  )
}
