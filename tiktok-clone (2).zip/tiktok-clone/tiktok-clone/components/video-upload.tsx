"use client"

import type React from "react"

import { useState, useRef, type ChangeEvent } from "react"
import { motion } from "framer-motion"
import { Upload, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNotification } from "@/contexts/notification-context"

interface VideoUploadProps {
  onUploadComplete: (videoUrl: string, thumbnailUrl: string) => void
  maxSizeMB?: number
}

export function VideoUpload({ onUploadComplete, maxSizeMB = 100 }: VideoUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { showNotification } = useNotification()

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    const droppedFile = e.dataTransfer.files[0]
    validateAndSetFile(droppedFile)
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0])
    }
  }

  const validateAndSetFile = (file: File) => {
    // Check if it's a video file
    if (!file.type.startsWith("video/")) {
      showNotification("error", "Please upload a video file")
      return
    }

    // Check file size
    const maxSizeBytes = maxSizeMB * 1024 * 1024
    if (file.size > maxSizeBytes) {
      showNotification("error", `File size exceeds the maximum limit of ${maxSizeMB}MB`)
      return
    }

    setFile(file)

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setPreviewUrl(url)
  }

  const handleUpload = async () => {
    if (!file) return

    setIsUploading(true)
    setUploadProgress(0)

    try {
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          const increment = Math.random() * 10
          const newProgress = prev + increment

          if (newProgress >= 100) {
            clearInterval(interval)
            return 100
          }

          return newProgress
        })
      }, 300)

      // Simulate upload delay
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // In a real app, you would upload to your backend here
      // const formData = new FormData()
      // formData.append("video", file)
      // const response = await fetch("/api/videos/upload", {
      //   method: "POST",
      //   body: formData,
      // })
      // const data = await response.json()

      // Mock successful upload
      clearInterval(interval)
      setUploadProgress(100)

      // Wait a bit to show 100% completion
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Mock response data
      const mockVideoUrl = "/joyful-street-dancer.png"
      const mockThumbnailUrl = "/joyful-street-dancer.png"

      onUploadComplete(mockVideoUrl, mockThumbnailUrl)
      showNotification("success", "Video uploaded successfully!")
    } catch (error) {
      showNotification("error", "Failed to upload video. Please try again.")
      console.error("Upload error:", error)
    } finally {
      setIsUploading(false)
      setFile(null)
      setPreviewUrl(null)
      setUploadProgress(0)

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const handleCancel = () => {
    setFile(null)
    setPreviewUrl(null)

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="w-full">
      {!file ? (
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? "border-primary bg-primary/10" : "border-border hover:border-primary/50 hover:bg-muted/50"
          }`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="p-3 rounded-full bg-primary/10 text-primary">
              <Upload className="h-8 w-8" />
            </div>
            <div>
              <p className="text-lg font-medium">Drag and drop your video here</p>
              <p className="text-sm text-muted-foreground mt-1">or click to browse (max {maxSizeMB}MB)</p>
            </div>
            <Button type="button" onClick={() => fileInputRef.current?.click()} className="mt-2">
              Select Video
            </Button>
            <input ref={fileInputRef} type="file" accept="video/*" onChange={handleFileChange} className="hidden" />
          </div>
        </div>
      ) : (
        <div className="border rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded bg-muted flex items-center justify-center mr-3">
                {previewUrl ? (
                  <video src={previewUrl} className="w-full h-full object-cover rounded" />
                ) : (
                  <div className="w-8 h-8 rounded-full border-2 border-muted-foreground border-t-transparent animate-spin" />
                )}
              </div>
              <div>
                <p className="font-medium truncate max-w-[200px]">{file.name}</p>
                <p className="text-xs text-muted-foreground">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
              </div>
            </div>
            {!isUploading && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCancel}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </Button>
            )}
          </div>

          {isUploading ? (
            <div className="space-y-2">
              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${uploadProgress}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>Uploading...</span>
                <span>{Math.round(uploadProgress)}%</span>
              </div>
            </div>
          ) : (
            <Button onClick={handleUpload} className="w-full">
              Upload Video
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
