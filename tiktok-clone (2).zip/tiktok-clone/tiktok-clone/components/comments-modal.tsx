"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Send, Heart } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/hooks/use-auth"
import { getSupabaseClient } from "@/lib/supabase-client"
import { useNotification } from "@/contexts/notification-context"

interface Comment {
  id: string
  content: string
  created_at: string
  likes: number
  user_id: string
  video_id: string
  user?: {
    username: string
    avatar: string
  }
}

interface CommentsModalProps {
  isOpen: boolean
  onClose: () => void
  videoId: string
}

export function CommentsModal({ isOpen, onClose, videoId }: CommentsModalProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { user } = useAuth()
  const { showNotification } = useNotification()
  const supabase = getSupabaseClient()

  // Fetch comments when modal opens
  useEffect(() => {
    if (isOpen && videoId) {
      fetchComments()
    }
  }, [isOpen, videoId])

  const fetchComments = async () => {
    if (!videoId) return

    setIsLoading(true)
    try {
      const { data, error } = await supabase
        .from("comments")
        .select("*")
        .eq("video_id", videoId)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching comments:", error)
        showNotification("error", "Failed to load comments")
        setComments([])
        return
      }

      // In a real app, you would fetch user data for each comment
      // For now, we'll use mock data
      const commentsWithUserData = data.map((comment) => ({
        ...comment,
        user: {
          username: `@user${comment.user_id.substring(0, 4)}`,
          avatar: `/diverse-avatars.png`,
        },
      }))

      setComments(commentsWithUserData)
    } catch (error) {
      console.error("Error fetching comments:", error)
      showNotification("error", "Failed to load comments")
      setComments([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newComment.trim() || !user) return

    setIsSubmitting(true)
    try {
      const { data, error } = await supabase
        .from("comments")
        .insert([
          {
            video_id: videoId,
            user_id: user.id,
            content: newComment.trim(),
          },
        ])
        .select()

      if (error) {
        throw error
      }

      // Add the new comment to the list with user data
      const newCommentWithUser = {
        ...data[0],
        user: {
          username: user.username,
          avatar: user.avatar || "/diverse-avatars.png",
        },
      }

      setComments([newCommentWithUser, ...comments])
      setNewComment("")
      showNotification("success", "Comment posted successfully")
    } catch (error) {
      console.error("Error posting comment:", error)
      showNotification("error", "Failed to post comment")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleLikeComment = async (commentId: string) => {
    if (!user) return

    try {
      // First, get the current likes count
      const { data: commentData, error: fetchError } = await supabase
        .from("comments")
        .select("likes")
        .eq("id", commentId)
        .single()

      if (fetchError) throw fetchError

      const currentLikes = commentData.likes || 0

      // Update the likes count
      const { error: updateError } = await supabase
        .from("comments")
        .update({ likes: currentLikes + 1 })
        .eq("id", commentId)

      if (updateError) throw updateError

      // Update the local state
      setComments(
        comments.map((comment) =>
          comment.id === commentId ? { ...comment, likes: (comment.likes || 0) + 1 } : comment,
        ),
      )
    } catch (error) {
      console.error("Error liking comment:", error)
      showNotification("error", "Failed to like comment")
    }
  }

  // Format timestamp to relative time (e.g., "2h ago")
  const formatRelativeTime = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds}s ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    return `${Math.floor(diffInSeconds / 86400)}d ago`
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 bg-card/95 backdrop-blur-md rounded-t-xl max-h-[80vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-lg font-semibold">Comments</h2>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : comments.length > 0 ? (
                comments.map((comment) => (
                  <motion.div
                    key={comment.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-3"
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={comment.user?.avatar || "/placeholder.svg"}
                        alt={comment.user?.username || "User"}
                      />
                      <AvatarFallback>{comment.user?.username?.[1] || "U"}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{comment.user?.username || "User"}</span>
                        <span className="text-xs text-muted-foreground">{formatRelativeTime(comment.created_at)}</span>
                      </div>
                      <p className="text-sm mt-1">{comment.content}</p>
                      <div className="flex items-center gap-3 mt-2">
                        <button
                          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                          onClick={() => handleLikeComment(comment.id)}
                        >
                          <Heart className="h-3.5 w-3.5" />
                          <span>{comment.likes || 0}</span>
                        </button>
                        <button className="text-xs text-muted-foreground hover:text-foreground">Reply</button>
                      </div>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No comments yet</p>
                  <p className="text-sm">Be the first to comment!</p>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-border">
              {user ? (
                <form onSubmit={handleSubmitComment} className="flex gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.username} />
                    <AvatarFallback>{user.username[1] || "U"}</AvatarFallback>
                  </Avatar>
                  <Input
                    className="flex-1 bg-muted border-muted"
                    placeholder="Add a comment..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    disabled={isSubmitting}
                  />
                  <Button
                    type="submit"
                    size="icon"
                    disabled={!newComment.trim() || isSubmitting}
                    className={!newComment.trim() ? "text-muted-foreground" : ""}
                  >
                    {isSubmitting ? (
                      <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </form>
              ) : (
                <div className="text-center py-2">
                  <p className="text-sm text-muted-foreground">
                    <Button variant="link" className="p-0 h-auto" onClick={() => (window.location.href = "/login")}>
                      Sign in
                    </Button>{" "}
                    to comment
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
