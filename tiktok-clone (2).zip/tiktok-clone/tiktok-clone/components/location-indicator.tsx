"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MapPin, X } from "lucide-react"
import { useLocation } from "@/hooks/use-location"

export function LocationIndicator() {
  const { status, location } = useLocation()
  const [showIndicator, setShowIndicator] = useState(false)
  const [locationName, setLocationName] = useState<string | null>(null)

  useEffect(() => {
    if (status === "granted" && location) {
      setShowIndicator(true)

      // In a real app, you would use reverse geocoding
      // For this demo, we'll simulate it
      setLocationName("San Francisco, CA")

      // Hide the indicator after 5 seconds
      const timer = setTimeout(() => {
        setShowIndicator(false)
      }, 5000)

      return () => clearTimeout(timer)
    }
  }, [status, location])

  return (
    <AnimatePresence>
      {showIndicator && (
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-zinc-900 rounded-full px-3 py-2 flex items-center shadow-lg z-50"
        >
          <div className="relative mr-2">
            <MapPin className="h-4 w-4 text-primary" />
            <motion.div
              className="absolute inset-0 rounded-full border border-primary"
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            />
          </div>
          <span className="text-xs font-medium">{locationName || "Location active"}</span>
          <button className="ml-2 p-1 rounded-full hover:bg-zinc-800" onClick={() => setShowIndicator(false)}>
            <X className="h-3 w-3" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
