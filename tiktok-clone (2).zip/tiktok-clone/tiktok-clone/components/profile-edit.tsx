"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Camera, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useForm } from "@/hooks/use-form"
import { useNotification } from "@/contexts/notification-context"
import { useMutation } from "@/hooks/use-api"
import { useAuth } from "@/hooks/use-auth"

interface ProfileEditProps {
  onClose: () => void
}

export function ProfileEdit({ onClose }: ProfileEditProps) {
  const { user } = useAuth()
  const { showNotification } = useNotification()
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)

  const { mutate: updateProfile, isLoading } = useMutation(`/users/${user?.id}`, {
    method: "PUT",
    requireAuth: true,
  })

  const { values, errors, touched, handleChange, handleBlur, handleSubmit } = useForm(
    {
      name: user?.name || "",
      username: user?.username || "",
      bio: user?.bio || "",
    },
    {
      name: { required: true, maxLength: 50 },
      username: { required: true, minLength: 3, maxLength: 30 },
      bio: { maxLength: 150 },
    },
    async (values) => {
      try {
        // In a real app, you would upload the avatar first if changed
        // const avatarUrl = avatarFile ? await uploadAvatar(avatarFile) : user?.avatar

        await updateProfile({
          ...values,
          // avatar: avatarUrl,
        })

        showNotification("success", "Profile updated successfully!")
        onClose()
      } catch (error) {
        showNotification("error", "Failed to update profile. Please try again.")
      }
    },
  )

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]

      // Check if it's an image
      if (!file.type.startsWith("image/")) {
        showNotification("error", "Please upload an image file")
        return
      }

      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        showNotification("error", "Image size should be less than 5MB")
        return
      }

      setAvatarFile(file)

      // Create preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setAvatarPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-card rounded-lg w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Edit Profile</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center">
            <div className="relative group">
              <div className="h-24 w-24 rounded-full overflow-hidden border-2 border-border">
                <img
                  src={avatarPreview || user?.avatar || "/placeholder.svg?height=96&width=96&query=avatar"}
                  alt="Profile"
                  className="h-full w-full object-cover"
                />
              </div>
              <label
                htmlFor="avatar-upload"
                className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              >
                <Camera className="h-6 w-6" />
              </label>
              <input id="avatar-upload" type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Tap to change profile photo</p>
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-1">
                Name
              </label>
              <Input
                id="name"
                name="name"
                value={values.name}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Your name"
                className={touched.name && errors.name ? "border-red-500" : ""}
              />
              {touched.name && errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>

            <div>
              <label htmlFor="username" className="block text-sm font-medium mb-1">
                Username
              </label>
              <Input
                id="username"
                name="username"
                value={values.username}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="@username"
                className={touched.username && errors.username ? "border-red-500" : ""}
              />
              {touched.username && errors.username && <p className="text-red-500 text-xs mt-1">{errors.username}</p>}
            </div>

            <div>
              <label htmlFor="bio" className="block text-sm font-medium mb-1">
                Bio
              </label>
              <Textarea
                id="bio"
                name="bio"
                value={values.bio}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Tell us about yourself"
                className={`resize-none h-20 ${touched.bio && errors.bio ? "border-red-500" : ""}`}
              />
              {touched.bio && errors.bio && <p className="text-red-500 text-xs mt-1">{errors.bio}</p>}
              <p className="text-xs text-muted-foreground mt-1">{values.bio.length}/150 characters</p>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={isLoading}>
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  )
}
