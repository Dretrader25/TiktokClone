type LocationStatus = "prompt" | "granted" | "denied" | "unavailable"

type Coordinates = {
  latitude: number
  longitude: number
  accuracy?: number
}

type LocationListener = (location: Coordinates | null, status: LocationStatus) => void

class LocationService {
  private static instance: LocationService
  private status: LocationStatus = "prompt"
  private currentLocation: Coordinates | null = null
  private watchId: number | null = null
  private listeners: LocationListener[] = []

  private constructor() {
    // Check if geolocation is available in the browser
    if (!navigator.geolocation) {
      this.status = "unavailable"
    }
  }

  public static getInstance(): LocationService {
    if (!LocationService.instance) {
      LocationService.instance = new LocationService()
    }
    return LocationService.instance
  }

  public getStatus(): LocationStatus {
    return this.status
  }

  public getCurrentLocation(): Coordinates | null {
    return this.currentLocation
  }

  public async requestPermission(): Promise<LocationStatus> {
    if (this.status === "unavailable") {
      return "unavailable"
    }

    try {
      const position = await this.getCurrentPositionPromise()
      this.currentLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
      }
      this.status = "granted"
      this.notifyListeners()
      return "granted"
    } catch (error) {
      if (error instanceof GeolocationPositionError) {
        if (error.code === error.PERMISSION_DENIED) {
          this.status = "denied"
        }
      } else {
        console.error("Error requesting location permission:", error)
      }
      this.notifyListeners()
      return this.status
    }
  }

  public startWatchingLocation(): void {
    if (this.status !== "granted" || this.watchId !== null) {
      return
    }

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        this.currentLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        }
        this.notifyListeners()
      },
      (error) => {
        console.error("Error watching location:", error)
        if (error.code === error.PERMISSION_DENIED) {
          this.status = "denied"
          this.stopWatchingLocation()
          this.notifyListeners()
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 30000, // 30 seconds
        timeout: 27000, // 27 seconds
      },
    )
  }

  public stopWatchingLocation(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
    }
  }

  public addListener(listener: LocationListener): () => void {
    this.listeners.push(listener)
    // Return a function to remove the listener
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      listener(this.currentLocation, this.status)
    }
  }

  private getCurrentPositionPromise(): Promise<GeolocationPosition> {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 10000, // 10 seconds
        maximumAge: 60000, // 1 minute
      })
    })
  }
}

export default LocationService
