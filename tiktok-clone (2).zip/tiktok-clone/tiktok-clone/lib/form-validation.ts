export type ValidationRule = {
  required?: boolean
  minLength?: number
  maxLength?: number
  pattern?: RegExp
  validate?: (value: any) => boolean | string
}

export type ValidationRules = Record<string, ValidationRule>

export type ValidationErrors = Record<string, string>

export function validateForm(values: Record<string, any>, rules: ValidationRules): ValidationErrors {
  const errors: ValidationErrors = {}

  Object.entries(rules).forEach(([field, rule]) => {
    const value = values[field]

    // Required check
    if (rule.required && (!value || (typeof value === "string" && value.trim() === ""))) {
      errors[field] = "This field is required"
      return
    }

    // Skip other validations if the field is empty and not required
    if (!value && !rule.required) {
      return
    }

    // Min length check
    if (rule.minLength !== undefined && typeof value === "string" && value.length < rule.minLength) {
      errors[field] = `Must be at least ${rule.minLength} characters`
      return
    }

    // Max length check
    if (rule.maxLength !== undefined && typeof value === "string" && value.length > rule.maxLength) {
      errors[field] = `Must be no more than ${rule.maxLength} characters`
      return
    }

    // Pattern check
    if (rule.pattern && typeof value === "string" && !rule.pattern.test(value)) {
      errors[field] = "Invalid format"
      return
    }

    // Custom validation
    if (rule.validate) {
      const result = rule.validate(value)
      if (typeof result === "string") {
        errors[field] = result
      } else if (result === false) {
        errors[field] = "Invalid value"
      }
    }
  })

  return errors
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0
}

// Common validation patterns
export const PATTERNS = {
  EMAIL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  USERNAME: /^[a-zA-Z0-9_]{3,20}$/,
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/,
  URL: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
}

// Common validation rules
export const RULES = {
  email: {
    required: true,
    pattern: PATTERNS.EMAIL,
  },
  username: {
    required: true,
    minLength: 3,
    maxLength: 20,
    pattern: PATTERNS.USERNAME,
  },
  password: {
    required: true,
    minLength: 8,
    pattern: PATTERNS.PASSWORD,
  },
  confirmPassword: {
    required: true,
    validate: (value: string, values: Record<string, any>) => value === values.password || "Passwords do not match",
  },
}
