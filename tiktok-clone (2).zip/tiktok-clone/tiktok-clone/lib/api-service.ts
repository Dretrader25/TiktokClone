import AuthService, { DEMO_ACCOUNT } from "./auth-service"

export type ApiOptions = {
  method?: string
  body?: any
  headers?: Record<string, string>
  requireAuth?: boolean
}

export type ApiError = {
  status: number
  message: string
  details?: any
}

class ApiService {
  private static instance: ApiService
  private baseUrl: string = process.env.NEXT_PUBLIC_API_URL || "https://api.example.com"

  private constructor() {}

  public static getInstance(): ApiService {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService()
    }
    return ApiService.instance
  }

  // Update the fetch method to handle unauthenticated requests more gracefully
  public async fetch<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
    const { method = "GET", body, headers = {}, requireAuth = false } = options

    const requestHeaders: Record<string, string> = {
      "Content-Type": "application/json",
      ...headers,
    }

    // Add auth token if required
    if (requireAuth) {
      const authService = AuthService.getInstance()
      const token = authService.getAccessToken()

      if (!token) {
        throw new Error("Authentication required")
      }

      requestHeaders["Authorization"] = `Bearer ${token}`
    }

    const requestOptions: RequestInit = {
      method,
      headers: requestHeaders,
      credentials: "include",
    }

    if (body) {
      requestOptions.body = JSON.stringify(body)
    }

    try {
      // For demo purposes, we'll use mock data instead of actual API calls
      const response = await this.mockApiCall(endpoint, requestOptions)
      return response as T
    } catch (error) {
      if (error instanceof Response) {
        const errorData = await error.json()
        throw {
          status: error.status,
          message: errorData.message || "An error occurred",
          details: errorData.details,
        } as ApiError
      }

      throw error
    }
  }

  // Mock API call function for demonstration
  private async mockApiCall(endpoint: string, options: RequestInit): Promise<any> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const authService = AuthService.getInstance()
    const isDemoUser = authService.isDemoUser()

    // If this is the demo user, provide rich demo data
    if (isDemoUser) {
      return this.handleDemoEndpoints(endpoint, options)
    }

    // Regular mock data based on the endpoint
    if (endpoint.startsWith("/videos")) {
      return this.handleVideoEndpoints(endpoint, options)
    } else if (endpoint.startsWith("/users")) {
      return this.handleUserEndpoints(endpoint, options)
    } else if (endpoint.startsWith("/comments")) {
      return this.handleCommentEndpoints(endpoint, options)
    }

    throw new Error(`Unhandled mock API call to ${endpoint}`)
  }

  // Special handler for demo account data
  private handleDemoEndpoints(endpoint: string, options: RequestInit): any {
    // Demo videos with rich content
    const DEMO_VIDEOS = [
      {
        id: "demo_video_1",
        userId: "demo_user",
        user: DEMO_ACCOUNT.userData,
        description: "Check out this amazing dance routine! #dance #trending",
        videoUrl: "/joyful-street-dancer.png",
        thumbnailUrl: "/joyful-street-dancer.png",
        likes: 12500,
        comments: 320,
        shares: 430,
        createdAt: "2023-05-15T14:30:00Z",
        audio: "Trending Dance Mix - DJ Demo",
        duration: 30,
      },
      {
        id: "demo_video_2",
        userId: "demo_user",
        user: DEMO_ACCOUNT.userData,
        description: "Beautiful sunset at the beach 🌅 #travel #sunset",
        videoUrl: "/vibrant-street-dance.png",
        thumbnailUrl: "/vibrant-street-dance.png",
        likes: 8700,
        comments: 145,
        shares: 220,
        createdAt: "2023-05-14T10:15:00Z",
        audio: "Chill Vibes - Summer Mix",
        duration: 45,
      },
      {
        id: "demo_video_3",
        userId: "demo_user",
        user: DEMO_ACCOUNT.userData,
        description: "My pet doing the funniest thing 😂 #pets #funny",
        videoUrl: "/squirrel-nut-heist.png",
        thumbnailUrl: "/squirrel-nut-heist.png",
        likes: 15900,
        comments: 540,
        shares: 760,
        createdAt: "2023-05-13T18:45:00Z",
        audio: "Original Sound - demouser",
        duration: 15,
      },
    ]

    // Demo comments with engagement
    const DEMO_COMMENTS = [
      {
        id: "demo_comment_1",
        videoId: "demo_video_1",
        userId: "user2",
        user: MOCK_USERS[1],
        text: "This is absolutely amazing! How long did it take you to learn this routine?",
        likes: 145,
        createdAt: "2023-05-15T15:30:00Z",
      },
      {
        id: "demo_comment_2",
        videoId: "demo_video_1",
        userId: "user3",
        user: MOCK_USERS[2],
        text: "You're so talented! 🔥🔥🔥",
        likes: 123,
        createdAt: "2023-05-15T16:15:00Z",
      },
      {
        id: "demo_comment_3",
        videoId: "demo_video_2",
        userId: "user1",
        user: MOCK_USERS[0],
        text: "Where is this beach? I need to visit!",
        likes: 78,
        createdAt: "2023-05-14T11:20:00Z",
      },
      {
        id: "demo_comment_4",
        videoId: "demo_video_3",
        userId: "user2",
        user: MOCK_USERS[1],
        text: "This made my day! 😂😂😂",
        likes: 167,
        createdAt: "2023-05-13T19:30:00Z",
      },
    ]

    // Handle different endpoints for the demo user
    if (endpoint === "/users/demo_user/videos" || endpoint === `/users/${DEMO_ACCOUNT.userData.id}/videos`) {
      return DEMO_VIDEOS
    } else if (endpoint.startsWith("/comments") && endpoint.includes("videoId=demo_video")) {
      const videoId = endpoint.split("=").pop()
      return DEMO_COMMENTS.filter((c) => c.videoId === videoId)
    } else if (endpoint === "/videos") {
      return DEMO_VIDEOS
    } else if (endpoint.match(/^\/videos\/demo_video_\d+$/)) {
      const id = endpoint.split("/").pop()
      const video = DEMO_VIDEOS.find((v) => v.id === id)
      if (!video) throw new Error("Video not found")
      return video
    } else if (endpoint === `/users/demo_user` || endpoint === `/users/${DEMO_ACCOUNT.userData.id}`) {
      return DEMO_ACCOUNT.userData
    }

    // Fall back to regular endpoints if no special demo handling
    if (endpoint.startsWith("/videos")) {
      return this.handleVideoEndpoints(endpoint, options)
    } else if (endpoint.startsWith("/users")) {
      return this.handleUserEndpoints(endpoint, options)
    } else if (endpoint.startsWith("/comments")) {
      return this.handleCommentEndpoints(endpoint, options)
    }

    throw new Error(`Unhandled demo endpoint: ${endpoint}`)
  }

  private handleVideoEndpoints(endpoint: string, options: RequestInit): any {
    // GET /videos
    if (endpoint === "/videos" && options.method === "GET") {
      return MOCK_VIDEOS
    }

    // GET /videos/:id
    if (endpoint.match(/^\/videos\/\w+$/) && options.method === "GET") {
      const id = endpoint.split("/").pop()
      const video = MOCK_VIDEOS.find((v) => v.id === id)
      if (!video) throw new Error("Video not found")
      return video
    }

    // POST /videos
    if (endpoint === "/videos" && options.method === "POST") {
      const body = JSON.parse(options.body as string)
      return {
        id: `video_${Date.now()}`,
        ...body,
        createdAt: new Date().toISOString(),
      }
    }

    // PUT /videos/:id
    if (endpoint.match(/^\/videos\/\w+$/) && options.method === "PUT") {
      const id = endpoint.split("/").pop()
      const video = MOCK_VIDEOS.find((v) => v.id === id)
      if (!video) throw new Error("Video not found")

      const body = JSON.parse(options.body as string)
      return { ...video, ...body, updatedAt: new Date().toISOString() }
    }

    // DELETE /videos/:id
    if (endpoint.match(/^\/videos\/\w+$/) && options.method === "DELETE") {
      return { success: true }
    }

    throw new Error(`Unhandled video endpoint: ${endpoint}`)
  }

  private handleUserEndpoints(endpoint: string, options: RequestInit): any {
    // GET /users
    if (endpoint === "/users" && options.method === "GET") {
      return MOCK_USERS
    }

    // GET /users/:id
    if (endpoint.match(/^\/users\/\w+$/) && options.method === "GET") {
      const id = endpoint.split("/").pop()
      const user = MOCK_USERS.find((u) => u.id === id)
      if (!user) throw new Error("User not found")
      return user
    }

    // GET /users/:id/videos
    if (endpoint.match(/^\/users\/\w+\/videos$/) && options.method === "GET") {
      const userId = endpoint.split("/")[2]
      return MOCK_VIDEOS.filter((v) => v.userId === userId)
    }

    // PUT /users/:id
    if (endpoint.match(/^\/users\/\w+$/) && options.method === "PUT") {
      const id = endpoint.split("/").pop()
      const user = MOCK_USERS.find((u) => u.id === id)
      if (!user) throw new Error("User not found")

      const body = JSON.parse(options.body as string)
      return { ...user, ...body }
    }

    throw new Error(`Unhandled user endpoint: ${endpoint}`)
  }

  private handleCommentEndpoints(endpoint: string, options: RequestInit): any {
    // GET /comments?videoId=:videoId
    if (endpoint.startsWith("/comments?videoId=") && options.method === "GET") {
      const videoId = endpoint.split("=").pop()
      return MOCK_COMMENTS.filter((c) => c.videoId === videoId)
    }

    // POST /comments
    if (endpoint === "/comments" && options.method === "POST") {
      const body = JSON.parse(options.body as string)
      return {
        id: `comment_${Date.now()}`,
        ...body,
        createdAt: new Date().toISOString(),
      }
    }

    // DELETE /comments/:id
    if (endpoint.match(/^\/comments\/\w+$/) && options.method === "DELETE") {
      return { success: true }
    }

    throw new Error(`Unhandled comment endpoint: ${endpoint}`)
  }
}

// Mock data
const MOCK_USERS = [
  {
    id: "user1",
    username: "@dancequeen",
    email: "dance@example.com",
    name: "Dance Queen",
    avatar: "/diverse-woman-avatars.png",
    isVerified: true,
    bio: "Professional dancer sharing tips and choreography",
    followersCount: 15000,
    followingCount: 250,
    likesCount: 120000,
  },
  {
    id: "user2",
    username: "@creativecoder",
    email: "coder@example.com",
    name: "Creative Coder",
    avatar: "/diverse-avatars.png",
    isVerified: false,
    bio: "Coding tutorials and tech tips",
    followersCount: 8500,
    followingCount: 320,
    likesCount: 75000,
  },
  {
    id: "user3",
    username: "@funnyguy",
    email: "funny@example.com",
    name: "Funny Guy",
    avatar: "/diverse-man-portrait.png",
    isVerified: true,
    bio: "Making you laugh daily",
    followersCount: 25000,
    followingCount: 450,
    likesCount: 300000,
  },
]

const MOCK_VIDEOS = [
  {
    id: "video1",
    userId: "user1",
    user: MOCK_USERS[0],
    description: "Check out this new dance routine! #dance #trending",
    videoUrl: "/joyful-street-dancer.png",
    thumbnailUrl: "/joyful-street-dancer.png",
    likes: 4500,
    comments: 120,
    shares: 230,
    createdAt: "2023-05-15T14:30:00Z",
    audio: "Original Sound - dancequeen",
    duration: 30,
  },
  {
    id: "video2",
    userId: "user2",
    user: MOCK_USERS[1],
    description: "How to build a responsive website in 10 minutes #coding #webdev",
    videoUrl: "/vibrant-street-dance.png",
    thumbnailUrl: "/vibrant-street-dance.png",
    likes: 2300,
    comments: 85,
    shares: 120,
    createdAt: "2023-05-14T10:15:00Z",
    audio: "Lofi Beats - studiomix",
    duration: 60,
  },
  {
    id: "video3",
    userId: "user3",
    user: MOCK_USERS[2],
    description: "When your code finally works after 5 hours of debugging 😂 #programming #humor",
    videoUrl: "/squirrel-nut-heist.png",
    thumbnailUrl: "/squirrel-nut-heist.png",
    likes: 8900,
    comments: 340,
    shares: 560,
    createdAt: "2023-05-13T18:45:00Z",
    audio: "Funny Sound Effect - meme",
    duration: 15,
  },
]

const MOCK_COMMENTS = [
  {
    id: "comment1",
    videoId: "video1",
    userId: "user2",
    user: MOCK_USERS[1],
    text: "Amazing dance moves! How long did it take you to learn this?",
    likes: 45,
    createdAt: "2023-05-15T15:30:00Z",
  },
  {
    id: "comment2",
    videoId: "video1",
    userId: "user3",
    user: MOCK_USERS[2],
    text: "This is so cool! 🔥",
    likes: 23,
    createdAt: "2023-05-15T16:15:00Z",
  },
  {
    id: "comment3",
    videoId: "video2",
    userId: "user1",
    user: MOCK_USERS[0],
    text: "Thanks for the tutorial, super helpful!",
    likes: 18,
    createdAt: "2023-05-14T11:20:00Z",
  },
  {
    id: "comment4",
    videoId: "video3",
    userId: "user2",
    user: MOCK_USERS[1],
    text: "Haha, I feel this on a spiritual level 😂",
    likes: 67,
    createdAt: "2023-05-13T19:30:00Z",
  },
]

export default ApiService
