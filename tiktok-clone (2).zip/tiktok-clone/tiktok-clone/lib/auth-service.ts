import { jwtDecode } from "jwt-decode"

export type User = {
  id: string
  username: string
  email: string
  name?: string
  avatar?: string
  isVerified?: boolean
  bio?: string
  followersCount?: number
  followingCount?: number
  likesCount?: number
}

export type AuthTokens = {
  accessToken: string
  refreshToken: string
}

export type LoginCredentials = {
  email: string
  password: string
}

export type RegisterCredentials = {
  email: string
  username: string
  password: string
  name?: string
}

// Demo account credentials for easy reference and validation
export const DEMO_ACCOUNT = {
  email: "user@example.com",
  password: "password",
  userData: {
    id: "demo_user",
    username: "@demouser",
    email: "user@example.com",
    name: "Demo User",
    avatar: "/diverse-avatars.png",
    isVerified: true,
    bio: "This is a demo account for exploring the TikTok Clone app ✨",
    followersCount: 8500,
    followingCount: 124,
    likesCount: 42000,
  },
}

class AuthService {
  private static instance: AuthService
  private user: User | null = null
  private tokens: AuthTokens | null = null
  private listeners: ((user: User | null) => void)[] = []
  private isDemoAccount = false

  private constructor() {
    // Initialize from localStorage if available
    if (typeof window !== "undefined") {
      const storedTokens = localStorage.getItem("auth_tokens")
      if (storedTokens) {
        try {
          this.tokens = JSON.parse(storedTokens)
          this.user = this.getUserFromToken(this.tokens.accessToken)

          // Check if this is the demo account
          if (this.user?.email === DEMO_ACCOUNT.email) {
            this.isDemoAccount = true
          }
        } catch (error) {
          console.error("Failed to parse stored tokens:", error)
          this.clearAuth()
        }
      }
    }
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  public async login(credentials: LoginCredentials): Promise<User> {
    try {
      // Check if this is the demo account
      const isDemo = credentials.email === DEMO_ACCOUNT.email && credentials.password === DEMO_ACCOUNT.password

      // In a real app, this would be an API call
      const response = await this.mockApiCall("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(credentials),
      })

      this.setTokens(response.tokens)
      this.user = response.user

      // Set demo flag if this is the demo account
      this.isDemoAccount = isDemo

      // Store demo status in localStorage for persistence
      if (isDemo && typeof window !== "undefined") {
        localStorage.setItem("is_demo_account", "true")
      }

      this.notifyListeners()
      return this.user
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    }
  }

  public async register(credentials: RegisterCredentials): Promise<User> {
    try {
      // In a real app, this would be an API call
      const response = await this.mockApiCall("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(credentials),
      })

      this.setTokens(response.tokens)
      this.user = response.user
      this.notifyListeners()
      return this.user
    } catch (error) {
      console.error("Registration failed:", error)
      throw error
    }
  }

  public async logout(): Promise<void> {
    try {
      // In a real app, this would be an API call to invalidate the token
      await this.mockApiCall("/api/auth/logout", {
        method: "POST",
      })
    } catch (error) {
      console.error("Logout API call failed:", error)
    } finally {
      this.clearAuth()
    }
  }

  public async refreshTokens(): Promise<boolean> {
    if (!this.tokens?.refreshToken) {
      return false
    }

    try {
      // In a real app, this would be an API call
      const response = await this.mockApiCall("/api/auth/refresh", {
        method: "POST",
        body: JSON.stringify({ refreshToken: this.tokens.refreshToken }),
      })

      this.setTokens(response.tokens)
      this.user = response.user
      this.notifyListeners()
      return true
    } catch (error) {
      console.error("Token refresh failed:", error)
      this.clearAuth()
      return false
    }
  }

  public getUser(): User | null {
    return this.user
  }

  public isAuthenticated(): boolean {
    return !!this.user && !!this.tokens?.accessToken
  }

  public getAccessToken(): string | null {
    return this.tokens?.accessToken || null
  }

  public isDemoUser(): boolean {
    return this.isDemoAccount
  }

  public addAuthChangeListener(listener: (user: User | null) => void): () => void {
    this.listeners.push(listener)
    // Return a function to remove the listener
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private setTokens(tokens: AuthTokens): void {
    this.tokens = tokens
    if (typeof window !== "undefined") {
      localStorage.setItem("auth_tokens", JSON.stringify(tokens))
    }
  }

  private clearAuth(): void {
    this.tokens = null
    this.user = null
    this.isDemoAccount = false
    if (typeof window !== "undefined") {
      localStorage.removeItem("auth_tokens")
      localStorage.removeItem("is_demo_account")
    }
    this.notifyListeners()
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      listener(this.user)
    }
  }

  private getUserFromToken(token: string): User | null {
    try {
      const decoded = jwtDecode<{ user: User }>(token)
      return decoded.user
    } catch (error) {
      console.error("Failed to decode token:", error)
      return null
    }
  }

  // Mock API call function for demonstration
  private async mockApiCall(url: string, options: RequestInit): Promise<any> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Mock responses based on the URL
    if (url === "/api/auth/login") {
      const { email, password } = JSON.parse(options.body as string)

      // Check if this is the demo account
      if (email === DEMO_ACCOUNT.email && password === DEMO_ACCOUNT.password) {
        return {
          user: DEMO_ACCOUNT.userData,
          tokens: {
            accessToken: "demo_access_token_" + Date.now(),
            refreshToken: "demo_refresh_token_" + Date.now(),
          },
        }
      }

      // Validate credentials (in a real app, this would be done on the server)
      if (email === "user@example.com" && password === "password") {
        return {
          user: {
            id: "user123",
            username: "@testuser",
            email: "user@example.com",
            name: "Test User",
            avatar: "/diverse-avatars.png",
            isVerified: true,
            bio: "Digital creator | Sharing short-form content ✨",
            followersCount: 8500,
            followingCount: 124,
            likesCount: 42000,
          },
          tokens: {
            accessToken: "mock_access_token_" + Date.now(),
            refreshToken: "mock_refresh_token_" + Date.now(),
          },
        }
      } else {
        throw new Error("Invalid credentials")
      }
    } else if (url === "/api/auth/register") {
      const { email, username, password, name } = JSON.parse(options.body as string)

      // Validate input (in a real app, this would be done on the server)
      if (!email || !username || !password) {
        throw new Error("Missing required fields")
      }

      // Check if email is already taken (mock check)
      if (email === "user@example.com") {
        throw new Error("Email already in use")
      }

      return {
        user: {
          id: "user_" + Date.now(),
          username,
          email,
          name: name || username,
          avatar: "/mystical-forest-spirit.png",
          isVerified: false,
          bio: "",
          followersCount: 0,
          followingCount: 0,
          likesCount: 0,
        },
        tokens: {
          accessToken: "mock_access_token_" + Date.now(),
          refreshToken: "mock_refresh_token_" + Date.now(),
        },
      }
    } else if (url === "/api/auth/logout") {
      return { success: true }
    } else if (url === "/api/auth/refresh") {
      // In a real app, this would validate the refresh token
      return {
        user: this.user,
        tokens: {
          accessToken: "mock_access_token_" + Date.now(),
          refreshToken: "mock_refresh_token_" + Date.now(),
        },
      }
    }

    throw new Error(`Unhandled mock API call to ${url}`)
  }
}

export default AuthService
