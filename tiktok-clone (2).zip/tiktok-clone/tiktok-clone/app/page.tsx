import Feed from "@/components/feed"
import { MobileNavbar } from "@/components/mobile-navbar"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center bg-background text-foreground">
      <Feed />
      <MobileNavbar />
    </main>
  )
}
