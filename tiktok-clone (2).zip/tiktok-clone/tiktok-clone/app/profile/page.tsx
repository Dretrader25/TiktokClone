"use client"

import { useState } from "react"
import { Edit, Grid, Settings } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MobileNavbar } from "@/components/mobile-navbar"
import { PageTransition } from "@/components/animated-components"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { ThemeToggle } from "@/components/theme-toggle"
import { useAuth } from "@/hooks/use-auth"
import { ProtectedRoute } from "@/components/protected-route"
import { ProfileEdit } from "@/components/profile-edit"
import { useApi } from "@/hooks/use-api"

export default function ProfilePage() {
  const { user, isDemoUser } = useAuth()
  const [showEditProfile, setShowEditProfile] = useState(false)

  const { data: userVideos, isLoading: isLoadingVideos } = useApi(`/users/${user?.id}/videos`, { requireAuth: false })

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-background text-foreground pb-16">
          <div className="p-4">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex justify-end mb-4 gap-2"
            >
              <ThemeToggle />
              <Link href="/settings">
                <motion.div
                  whileHover={{ scale: 1.1, backgroundColor: "rgba(39, 39, 42, 0.5)" }}
                  whileTap={{ scale: 0.9 }}
                  className="rounded-full p-2 transition-colors"
                >
                  <Settings className="h-6 w-6" />
                </motion.div>
              </Link>
            </motion.div>

            <div className="flex flex-col items-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 260, damping: 20 }}
                className="h-24 w-24 rounded-full overflow-hidden border-2 border-border mb-4"
              >
                <img
                  src={user?.avatar || "/diverse-avatars.png"}
                  alt="Profile"
                  className="h-full w-full object-cover"
                />
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xl font-bold mb-1"
              >
                {user?.username || "@username"}
              </motion.h1>

              {isDemoUser && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-primary/20 text-primary text-xs font-medium px-2 py-1 rounded-full mb-2"
                >
                  Demo Account
                </motion.div>
              )}

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, staggerChildren: 0.1 }}
                className="flex gap-6 my-4"
              >
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="flex flex-col items-center"
                >
                  <span className="font-bold">{user?.followingCount || 0}</span>
                  <span className="text-sm text-muted-foreground">Following</span>
                </motion.div>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="flex flex-col items-center"
                >
                  <span className="font-bold">{user?.followersCount || 0}</span>
                  <span className="text-sm text-muted-foreground">Followers</span>
                </motion.div>
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="flex flex-col items-center"
                >
                  <span className="font-bold">{user?.likesCount || 0}</span>
                  <span className="text-sm text-muted-foreground">Likes</span>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                className="flex gap-2 w-full max-w-xs mb-6"
              >
                <Button
                  className="flex-1"
                  variant="outline"
                  onClick={() => {
                    if (isDemoUser) {
                      toast({
                        title: "Demo Account",
                        description: "Profile editing is limited in demo mode, but you can explore the interface!",
                        duration: 3000,
                      })
                    }
                    setShowEditProfile(true)
                  }}
                >
                  Edit Profile
                  <Edit className="h-4 w-4 ml-2" />
                </Button>
                <Button
                  className="flex-1"
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Share Profile",
                      description: "Profile sharing options would appear here.",
                      duration: 2000,
                    })
                  }}
                >
                  Share Profile
                </Button>
              </motion.div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="text-center text-sm mb-6 max-w-xs"
              >
                {user?.bio || "Digital creator | Sharing short-form content ✨ New videos every day ✨"}
              </motion.p>
            </div>

            <Tabs defaultValue="videos" className="w-full">
              <TabsList className="w-full bg-muted">
                <TabsTrigger value="videos" className="flex-1">
                  <Grid className="h-5 w-5" />
                </TabsTrigger>
                <TabsTrigger value="liked" className="flex-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-heart"
                  >
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                  </svg>
                </TabsTrigger>
              </TabsList>
              <TabsContent value="videos" className="mt-4">
                {isLoadingVideos ? (
                  <div className="flex justify-center py-8">
                    <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : userVideos && userVideos.length > 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ staggerChildren: 0.05 }}
                    className="grid grid-cols-3 gap-1"
                  >
                    {userVideos.map((video: any, i: number) => (
                      <motion.div
                        key={video.id}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        whileHover={{ scale: 1.05 }}
                        className="aspect-square bg-muted relative overflow-hidden rounded-md"
                      >
                        <img
                          src={video.thumbnailUrl || "/video-marketing-thumbnails.png"}
                          alt={`Video ${i + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-1 right-1 bg-black/60 px-1 py-0.5 rounded text-xs">
                          {video.likes} likes
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">
                      {isDemoUser ? "Demo videos will appear here. Try refreshing the page!" : "No videos yet"}
                    </p>
                    <Link href="/create">
                      <Button className="mt-4">Create Your First Video</Button>
                    </Link>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="liked" className="mt-4">
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    {isDemoUser ? "Demo liked videos would appear here" : "Liked videos will appear here"}
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <AnimatePresence>
            {showEditProfile && <ProfileEdit onClose={() => setShowEditProfile(false)} />}
          </AnimatePresence>

          <MobileNavbar />
          <Toaster />
        </div>
      </PageTransition>
    </ProtectedRoute>
  )
}
