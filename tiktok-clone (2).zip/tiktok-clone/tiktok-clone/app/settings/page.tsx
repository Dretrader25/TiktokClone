"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Bell, Lock, HelpCircle, LogOut, ChevronRight, User, Smartphone, Eye } from "lucide-react"
import { motion } from "framer-motion"
import Link from "next/link"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { PageTransition, SlideUp } from "@/components/animated-components"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { useTheme } from "@/components/theme-provider"
import { ThemeModeToggle } from "@/components/ui/theme-mode-toggle"
import { useAuth } from "@/hooks/use-auth"
import { ProtectedRoute } from "@/components/protected-route"
import { useNotification } from "@/contexts/notification-context"

// Settings sections with their options
const SETTINGS_SECTIONS = [
  {
    id: "account",
    title: "Account",
    icon: <User className="h-5 w-5" />,
    options: [
      { id: "profile", label: "Edit Profile", hasToggle: false, hasNavigation: true },
      { id: "phone", label: "Phone Number", hasToggle: false, hasNavigation: true },
      { id: "email", label: "Email", hasToggle: false, hasNavigation: true },
      { id: "password", label: "Password", hasToggle: false, hasNavigation: true },
    ],
  },
  {
    id: "privacy",
    title: "Privacy",
    icon: <Lock className="h-5 w-5" />,
    options: [
      { id: "private-account", label: "Private Account", hasToggle: true, hasNavigation: false },
      { id: "comments", label: "Comments", hasToggle: false, hasNavigation: true },
      { id: "duet", label: "Allow Duets", hasToggle: true, hasNavigation: false },
      { id: "liked-videos", label: "Who Can View Your Liked Videos", hasToggle: false, hasNavigation: true },
    ],
  },
  {
    id: "notifications",
    title: "Notifications",
    icon: <Bell className="h-5 w-5" />,
    options: [
      { id: "app-notifications", label: "App Notifications", hasToggle: false, hasNavigation: true },
      { id: "email-notifications", label: "Email Notifications", hasToggle: false, hasNavigation: true },
      { id: "likes", label: "Likes", hasToggle: true, hasNavigation: false },
      { id: "comments", label: "Comments", hasToggle: true, hasNavigation: false },
      { id: "followers", label: "New Followers", hasToggle: true, hasNavigation: false },
      { id: "mentions", label: "Mentions", hasToggle: true, hasNavigation: false },
    ],
  },
  {
    id: "appearance",
    title: "Appearance",
    icon: <Eye className="h-5 w-5" />,
    options: [
      { id: "dark-mode", label: "Dark Mode", hasToggle: true, hasNavigation: false },
      { id: "data-saver", label: "Data Saver", hasToggle: true, hasNavigation: false },
      { id: "accessibility", label: "Accessibility", hasToggle: false, hasNavigation: true },
    ],
  },
  {
    id: "general",
    title: "General",
    icon: <Smartphone className="h-5 w-5" />,
    options: [
      { id: "language", label: "Language", hasToggle: false, hasNavigation: true, value: "English" },
      { id: "region", label: "Region", hasToggle: false, hasNavigation: true, value: "United States" },
      { id: "clear-cache", label: "Clear Cache", hasToggle: false, hasNavigation: true },
      { id: "free-up-space", label: "Free Up Space", hasToggle: false, hasNavigation: true },
    ],
  },
  {
    id: "support",
    title: "Support",
    icon: <HelpCircle className="h-5 w-5" />,
    options: [
      { id: "report-problem", label: "Report a Problem", hasToggle: false, hasNavigation: true },
      { id: "help-center", label: "Help Center", hasToggle: false, hasNavigation: true },
      { id: "safety-center", label: "Safety Center", hasToggle: false, hasNavigation: true },
      { id: "community-guidelines", label: "Community Guidelines", hasToggle: false, hasNavigation: true },
    ],
  },
]

export default function SettingsPage() {
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const { logout } = useAuth()
  const { showNotification } = useNotification()

  const [toggleStates, setToggleStates] = useState<Record<string, boolean>>({
    "private-account": false,
    duet: true,
    likes: true,
    comments: true,
    followers: true,
    mentions: false,
    "dark-mode": theme === "dark",
    "data-saver": false,
  })

  // Update toggleStates when theme changes
  useEffect(() => {
    setToggleStates((prev) => ({
      ...prev,
      "dark-mode": theme === "dark",
    }))
  }, [theme])

  const handleToggleChange = (optionId: string) => {
    try {
      if (optionId === "dark-mode") {
        const newThemeValue = !toggleStates["dark-mode"]
        setTheme(newThemeValue ? "dark" : "light")

        setToggleStates((prev) => {
          const newState = { ...prev, [optionId]: newThemeValue }

          // Show success toast
          toast({
            title: "Setting updated",
            description: `Dark mode has been ${newThemeValue ? "enabled" : "disabled"}.`,
            duration: 2000,
          })

          return newState
        })
      } else {
        setToggleStates((prev) => {
          const newState = { ...prev, [optionId]: !prev[optionId] }

          // In a real app, you would save this to a backend or local storage
          console.log(`Setting ${optionId} changed to: ${newState[optionId]}`)

          // Show success toast
          toast({
            title: "Setting updated",
            description: `${optionId
              .split("-")
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" ")} has been ${newState[optionId] ? "enabled" : "disabled"}.`,
            duration: 2000,
          })

          return newState
        })
      }
    } catch (error) {
      // Show error toast
      toast({
        title: "Error updating setting",
        description: "There was a problem updating your setting. Please try again.",
        variant: "destructive",
        duration: 3000,
      })
      console.error("Error updating setting:", error)
    }
  }

  // Handle navigation to specific setting detail pages
  const handleNavigateToSetting = (sectionId: string, optionId: string) => {
    // In a real app, you would navigate to a specific settings detail page
    console.log(`Navigating to ${sectionId}/${optionId}`)

    // For demo purposes, just show a toast
    toast({
      title: "Navigation",
      description: `Navigating to ${optionId
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")} settings.`,
      duration: 2000,
    })
  }

  // Handle logout
  const handleLogout = async () => {
    try {
      showNotification("info", "Logging out...")
      await logout()
      router.push("/login")
    } catch (error) {
      showNotification("error", "Failed to log out. Please try again.")
    }
  }

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-background text-foreground">
          <div className="sticky top-0 z-10 bg-background border-b border-border">
            <div className="flex items-center p-4">
              <Link href="/profile">
                <Button variant="ghost" size="icon" className="mr-2">
                  <ArrowLeft className="h-6 w-6" />
                </Button>
              </Link>
              <h1 className="text-xl font-bold">Settings</h1>
            </div>
          </div>

          <div className="pb-20">
            {SETTINGS_SECTIONS.map((section, sectionIndex) => (
              <SlideUp key={section.id} delay={sectionIndex * 0.05}>
                <div className="mb-6">
                  <div className="px-4 py-2 flex items-center">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center mr-2">
                      {section.icon}
                    </div>
                    <h2 className="text-lg font-semibold">{section.title}</h2>
                  </div>

                  <div className="bg-card rounded-lg mx-4 overflow-hidden">
                    {section.options.map((option) => (
                      <motion.div
                        key={option.id}
                        whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.5)" }}
                        className="flex items-center justify-between p-4 border-b border-border last:border-b-0"
                        onClick={() => option.hasNavigation && handleNavigateToSetting(section.id, option.id)}
                      >
                        <div className="flex-1">
                          <p className="font-medium">{option.label}</p>
                          {option.value && <p className="text-xs text-muted-foreground">{option.value}</p>}
                        </div>

                        {option.id === "dark-mode" ? (
                          <ThemeModeToggle
                            onToggle={(checked) => {
                              setToggleStates((prev) => ({ ...prev, "dark-mode": checked }))
                              toast({
                                title: "Setting updated",
                                description: `Dark mode has been ${checked ? "enabled" : "disabled"}.`,
                                duration: 2000,
                              })
                            }}
                          />
                        ) : option.hasToggle ? (
                          <Switch
                            checked={toggleStates[option.id] || false}
                            onCheckedChange={() => handleToggleChange(option.id)}
                            className="data-[state=checked]:bg-primary"
                          />
                        ) : option.hasNavigation ? (
                          <ChevronRight className="h-5 w-5 text-muted-foreground" />
                        ) : null}
                      </motion.div>
                    ))}
                  </div>
                </div>
              </SlideUp>
            ))}

            <SlideUp delay={0.4}>
              <div className="px-4 mb-10">
                <motion.button
                  whileHover={{ backgroundColor: "rgba(239, 68, 68, 0.1)" }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 text-red-500 font-medium rounded-lg flex items-center justify-center"
                  onClick={handleLogout}
                >
                  <LogOut className="h-5 w-5 mr-2" />
                  Log Out
                </motion.button>
              </div>
            </SlideUp>

            <SlideUp delay={0.5}>
              <div className="px-4 text-center text-xs text-muted-foreground mb-6">
                <p>Version 1.0.0</p>
                <p className="mt-1">© 2023 TikTok Clone</p>
              </div>
            </SlideUp>
          </div>

          <Toaster />
        </div>
      </PageTransition>
    </ProtectedRoute>
  )
}
