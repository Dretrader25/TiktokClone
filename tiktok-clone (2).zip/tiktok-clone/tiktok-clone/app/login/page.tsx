"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Eye, EyeOff, LogIn } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/hooks/use-auth"
import { useForm } from "@/hooks/use-form"
import { RULES } from "@/lib/form-validation"
import { useNotification } from "@/contexts/notification-context"
import { AuthBackground } from "@/components/auth-background"
import { AuthLoading } from "@/components/auth-loading"
import { AuthSuccess } from "@/components/auth-success"
import { DEMO_ACCOUNT } from "@/lib/auth-service"

export default function LoginPage() {
  const router = useRouter()
  const { login, loginWithDemo, isAuthenticated } = useAuth()
  const { showNotification } = useNotification()
  const [showPassword, setShowPassword] = useState(false)
  const [authState, setAuthState] = useState<"idle" | "loading" | "success">("idle")

  // Update the useEffect hook to handle redirects better
  useEffect(() => {
    if (isAuthenticated) {
      const redirectPath = typeof window !== "undefined" ? sessionStorage.getItem("redirectAfterLogin") || "/" : "/"

      if (typeof window !== "undefined") {
        sessionStorage.removeItem("redirectAfterLogin")
      }

      router.push(redirectPath)
    }
  }, [isAuthenticated, router])

  const { values, errors, touched, isSubmitting, handleChange, handleBlur, handleSubmit, setFieldValue } = useForm(
    {
      email: "",
      password: "",
    },
    {
      email: RULES.email,
      password: {
        required: true,
      },
    },
    async (values) => {
      try {
        setAuthState("loading")
        await login({
          email: values.email,
          password: values.password,
        })
        setAuthState("success")

        // Show success animation before redirecting
        setTimeout(() => {
          showNotification("success", "Login successful!")
          // Router will handle redirect in the useEffect above
        }, 1500)
      } catch (error) {
        setAuthState("idle")
        showNotification("error", error instanceof Error ? error.message : "Login failed")
      }
    },
  )

  const toggleShowPassword = () => {
    setShowPassword(!showPassword)
  }

  // Demo credentials for easy testing
  const fillDemoCredentials = () => {
    setFieldValue("email", DEMO_ACCOUNT.email)
    setFieldValue("password", DEMO_ACCOUNT.password)
  }

  // Handle demo login
  const handleDemoLogin = async () => {
    try {
      setAuthState("loading")
      await loginWithDemo()
      setAuthState("success")

      // Show success animation before redirecting
      setTimeout(() => {
        showNotification("success", "Demo login successful! Explore the app freely.")
        // Router will handle redirect in the useEffect above
      }, 1500)
    } catch (error) {
      setAuthState("idle")
      showNotification("error", error instanceof Error ? error.message : "Demo login failed")
    }
  }

  return (
    <div className="min-h-screen w-full overflow-hidden">
      {/* Background */}
      <AuthBackground />

      {/* Loading and Success States */}
      <AnimatePresence>
        {authState === "loading" && <AuthLoading />}
        {authState === "success" && <AuthSuccess />}
      </AnimatePresence>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Logo and App Name */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="flex flex-col items-center mb-8"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.3 }}
              className="w-20 h-20 bg-gradient-to-br from-pink-500 to-violet-500 rounded-2xl flex items-center justify-center mb-4 shadow-lg"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-white"
              >
                <path d="M21 8v8a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5h8a5 5 0 0 1 5 5Z"></path>
                <path d="m10 15 5-5"></path>
                <path d="M7.5 12.5v-1"></path>
                <path d="M16.5 11.5v1"></path>
              </svg>
            </motion.div>
            <motion.h1
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-3xl font-bold text-white mb-1"
            >
              TikTok Clone
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-zinc-400"
            >
              Sign in to continue
            </motion.p>
          </motion.div>

          {/* Form Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="bg-zinc-900/70 backdrop-blur-md p-8 rounded-2xl shadow-xl border border-zinc-800"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                className="space-y-2"
              >
                <label htmlFor="email" className="block text-sm font-medium text-zinc-300">
                  Email
                </label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  placeholder="Enter your email"
                  className={`w-full bg-zinc-800/50 border-zinc-700 focus:border-primary ${
                    touched.email && errors.email ? "border-red-500 focus-visible:ring-red-500" : ""
                  }`}
                />
                {touched.email && errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 }}
                className="space-y-2"
              >
                <label htmlFor="password" className="block text-sm font-medium text-zinc-300">
                  Password
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={values.password}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Enter your password"
                    className={`w-full pr-10 bg-zinc-800/50 border-zinc-700 focus:border-primary ${
                      touched.password && errors.password ? "border-red-500 focus-visible:ring-red-500" : ""
                    }`}
                  />
                  <button
                    type="button"
                    onClick={toggleShowPassword}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-zinc-400 hover:text-zinc-300"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {touched.password && errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 }}
                className="flex items-center justify-between"
              >
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 rounded border-zinc-700 text-primary focus:ring-primary bg-zinc-800"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-zinc-400">
                    Remember me
                  </label>
                </div>
                <div className="text-sm">
                  <Link href="/forgot-password" className="text-primary hover:text-primary/80">
                    Forgot password?
                  </Link>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1 }}>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-pink-500 to-violet-500 hover:from-pink-600 hover:to-violet-600 text-white py-2 h-12 font-medium"
                  disabled={isSubmitting || authState !== "idle"}
                >
                  {isSubmitting || authState !== "idle" ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Signing in...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <LogIn className="h-4 w-4" />
                      <span>Sign in</span>
                    </div>
                  )}
                </Button>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.1 }}
                className="text-center mt-4"
              >
                <p className="text-sm text-zinc-400">
                  Don&apos;t have an account?{" "}
                  <Link href="/register" className="text-primary hover:text-primary/80 font-medium">
                    Sign up
                  </Link>
                </p>
              </motion.div>
            </form>

            {/* Demo Account Button */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
              className="mt-6 pt-6 border-t border-zinc-800"
            >
              <div className="space-y-3">
                <button
                  type="button"
                  onClick={fillDemoCredentials}
                  className="w-full py-2 px-4 bg-zinc-800 hover:bg-zinc-700 rounded-md text-sm text-zinc-300 transition-colors"
                >
                  Fill demo credentials
                </button>
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full py-2 px-4 bg-primary/20 hover:bg-primary/30 text-primary rounded-md text-sm font-medium transition-colors"
                >
                  Login as demo user
                </button>
              </div>
              <p className="text-xs text-zinc-500 mt-2 text-center">For testing: user@example.com / password</p>
            </motion.div>
          </motion.div>

          {/* Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
            className="text-center mt-8 text-xs text-zinc-500"
          >
            <p>© 2025 User Group LLC</p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}
