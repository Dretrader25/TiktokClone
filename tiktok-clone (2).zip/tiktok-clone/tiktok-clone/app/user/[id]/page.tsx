"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Grid } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { MobileNavbar } from "@/components/mobile-navbar"
import { PageTransition, SlideUp } from "@/components/animated-components"
import { useNotification } from "@/contexts/notification-context"

// Mock user data - in a real app, this would come from your database
const MOCK_USERS = {
  user1: {
    id: "user1",
    username: "@dancequeen",
    name: "Dance Queen",
    bio: "Professional dancer sharing tips and choreography ✨",
    avatar: "/diverse-woman-avatars.png",
    isVerified: true,
    followersCount: 15000,
    followingCount: 250,
    likesCount: 120000,
    videos: [
      { id: "v1", thumbnail: "/vibrant-street-dance.png", views: "8.7M" },
      { id: "v2", thumbnail: "/joyful-street-dancer.png", views: "4.2M" },
      { id: "v3", thumbnail: "/vibrant-city-busker.png", views: "2.1M" },
    ],
  },
  user2: {
    id: "user2",
    username: "@creativecoder",
    name: "Creative Coder",
    bio: "Coding tutorials and tech tips 💻",
    avatar: "/diverse-avatars.png",
    isVerified: false,
    followersCount: 8500,
    followingCount: 320,
    likesCount: 75000,
    videos: [
      { id: "v4", thumbnail: "/joyful-street-dancer.png", views: "1.2M" },
      { id: "v5", thumbnail: "/squirrel-nut-heist.png", views: "950K" },
    ],
  },
  user3: {
    id: "user3",
    username: "@funnyguy",
    name: "Funny Guy",
    bio: "Making you laugh daily 😂",
    avatar: "/diverse-man-portrait.png",
    isVerified: true,
    followersCount: 25000,
    followingCount: 450,
    likesCount: 300000,
    videos: [
      { id: "v6", thumbnail: "/squirrel-nut-heist.png", views: "8.9M" },
      { id: "v7", thumbnail: "/comedic-stage-mishap.png", views: "5.4M" },
      { id: "v8", thumbnail: "/vibrant-street-dance.png", views: "3.2M" },
    ],
  },
}

export default function UserProfilePage() {
  const params = useParams()
  const router = useRouter()
  const { showNotification } = useNotification()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isFollowing, setIsFollowing] = useState(false)

  useEffect(() => {
    const userId = params.id as string

    // In a real app, you would fetch user data from your database
    // For now, we'll use mock data
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      const userData = MOCK_USERS[userId as keyof typeof MOCK_USERS]
      if (userData) {
        setUser(userData)
      } else {
        showNotification("error", "User not found")
        router.push("/")
      }
      setIsLoading(false)
    }, 500)
  }, [params.id, router, showNotification])

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
    showNotification("success", isFollowing ? "Unfollowed user" : "Following user")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">User not found</h2>
          <Button onClick={() => router.push("/")}>Go Home</Button>
        </div>
      </div>
    )
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background text-foreground pb-16">
        <div className="sticky top-0 z-10 bg-background">
          <div className="flex items-center p-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h1 className="text-xl font-bold ml-2">{user.username}</h1>
          </div>
        </div>

        <div className="p-4">
          <div className="flex flex-col items-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 20 }}
              className="h-24 w-24 rounded-full overflow-hidden border-2 border-border mb-4"
            >
              <img src={user.avatar || "/placeholder.svg"} alt="Profile" className="h-full w-full object-cover" />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl font-bold mb-1 flex items-center"
            >
              {user.name}
              {user.isVerified && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="w-5 h-5 ml-1 text-blue-400"
                >
                  <path
                    fillRule="evenodd"
                    d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                    clipRule="evenodd"
                  />
                </svg>
              )}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-sm text-muted-foreground mb-4"
            >
              {user.username}
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, staggerChildren: 0.1 }}
              className="flex gap-6 my-4"
            >
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="flex flex-col items-center"
              >
                <span className="font-bold">{user.followingCount}</span>
                <span className="text-sm text-muted-foreground">Following</span>
              </motion.div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="flex flex-col items-center"
              >
                <span className="font-bold">{user.followersCount}</span>
                <span className="text-sm text-muted-foreground">Followers</span>
              </motion.div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex flex-col items-center"
              >
                <span className="font-bold">{user.likesCount}</span>
                <span className="text-sm text-muted-foreground">Likes</span>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="w-full max-w-xs mb-6"
            >
              <Button className="w-full" variant={isFollowing ? "outline" : "default"} onClick={handleFollow}>
                {isFollowing ? "Following" : "Follow"}
              </Button>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="text-center text-sm mb-6 max-w-xs"
            >
              {user.bio}
            </motion.p>
          </div>

          <SlideUp delay={0.8}>
            <div className="mb-4">
              <h2 className="text-lg font-bold flex items-center mb-3">
                <Grid className="h-5 w-5 mr-2" />
                Videos
              </h2>
              <div className="grid grid-cols-3 gap-1">
                {user.videos.map((video: any, i: number) => (
                  <motion.div
                    key={video.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.8 + i * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="aspect-square bg-muted relative overflow-hidden rounded-md cursor-pointer"
                    onClick={() => router.push(`/video/${video.id}`)}
                  >
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={`Video ${i + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/60 px-1 py-0.5 rounded text-xs">
                      {video.views}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </SlideUp>
        </div>

        <MobileNavbar />
      </div>
    </PageTransition>
  )
}
