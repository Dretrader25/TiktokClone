"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowLeft, Hash, Music2, MapPin } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { PageTransition, SlideUp } from "@/components/animated-components"
import { VideoUpload } from "@/components/video-upload"
import { useNotification } from "@/contexts/notification-context"
import { ProtectedRoute } from "@/components/protected-route"
import { MobileNavbar } from "@/components/mobile-navbar"
import { useMutation } from "@/hooks/use-api"

export default function CreatePage() {
  const router = useRouter()
  const { showNotification } = useNotification()
  const [step, setStep] = useState<"upload" | "details">("upload")
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null)
  const [description, setDescription] = useState("")
  const [allowComments, setAllowComments] = useState(true)
  const [allowDuets, setAllowDuets] = useState(true)
  const [isPublic, setIsPublic] = useState(true)
  const [location, setLocation] = useState("")

  const { mutate: createVideo, isLoading } = useMutation("/videos", { requireAuth: true })

  const handleUploadComplete = (videoUrl: string, thumbnailUrl: string) => {
    setVideoUrl(videoUrl)
    setThumbnailUrl(thumbnailUrl)
    setStep("details")
  }

  const handleSubmit = async () => {
    if (!videoUrl || !thumbnailUrl) {
      showNotification("error", "Video upload is required")
      return
    }

    try {
      await createVideo({
        videoUrl,
        thumbnailUrl,
        description,
        allowComments,
        allowDuets,
        isPublic,
        location: location || undefined,
      })

      showNotification("success", "Video posted successfully!")
      router.push("/")
    } catch (error) {
      showNotification("error", "Failed to post video. Please try again.")
    }
  }

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-background text-foreground pb-16">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="flex items-center justify-between p-4 border-b border-border"
          >
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Create New Video</h1>
            <div className="w-10" />
          </motion.div>

          <div className="max-w-md mx-auto p-4">
            {step === "upload" ? (
              <SlideUp>
                <h2 className="text-lg font-semibold mb-4">Upload Video</h2>
                <VideoUpload onUploadComplete={handleUploadComplete} />
              </SlideUp>
            ) : (
              <SlideUp>
                <h2 className="text-lg font-semibold mb-4">Video Details</h2>

                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-24 h-32 bg-muted rounded-md overflow-hidden">
                      {thumbnailUrl && (
                        <img
                          src={thumbnailUrl || "/placeholder.svg"}
                          alt="Video thumbnail"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="flex-1 space-y-2">
                      <label className="text-sm font-medium">Description</label>
                      <Textarea
                        placeholder="Write a description for your video..."
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="resize-none h-24"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 bg-muted/50 p-3 rounded-lg">
                      <Hash className="h-5 w-5 text-primary" />
                      <Input
                        placeholder="Add hashtags"
                        className="border-none bg-transparent focus-visible:ring-0 p-0"
                      />
                    </div>

                    <div className="flex items-center gap-3 bg-muted/50 p-3 rounded-lg">
                      <Music2 className="h-5 w-5 text-primary" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Original Sound</p>
                        <p className="text-xs text-muted-foreground">Use original audio</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 bg-muted/50 p-3 rounded-lg">
                      <MapPin className="h-5 w-5 text-primary" />
                      <Input
                        placeholder="Add location"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="border-none bg-transparent focus-visible:ring-0 p-0"
                      />
                    </div>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Allow comments</p>
                        <p className="text-xs text-muted-foreground">Let others comment on your video</p>
                      </div>
                      <Switch checked={allowComments} onCheckedChange={setAllowComments} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Allow duets</p>
                        <p className="text-xs text-muted-foreground">Let others create duets with your video</p>
                      </div>
                      <Switch checked={allowDuets} onCheckedChange={setAllowDuets} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Who can view</p>
                        <p className="text-xs text-muted-foreground">{isPublic ? "Everyone" : "Only me"}</p>
                      </div>
                      <Switch checked={isPublic} onCheckedChange={setIsPublic} />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button variant="outline" className="flex-1" onClick={() => setStep("upload")}>
                      Back
                    </Button>
                    <Button className="flex-1" onClick={handleSubmit} disabled={isLoading}>
                      {isLoading ? "Posting..." : "Post Video"}
                    </Button>
                  </div>
                </div>
              </SlideUp>
            )}
          </div>

          <MobileNavbar />
        </div>
      </PageTransition>
    </ProtectedRoute>
  )
}
