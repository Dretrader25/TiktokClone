"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { ProtectedRoute } from "@/components/protected-route"
import { PageTransition } from "@/components/animated-components"
import { Loader } from "lucide-react"

export default function InboxPage() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the combined messages page
    router.push("/messages")
  }, [router])

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
          <div className="flex flex-col items-center">
            <Loader className="h-8 w-8 animate-spin text-primary" />
            <p className="mt-4 text-zinc-400">Redirecting to messages...</p>
          </div>
        </div>
      </PageTransition>
    </ProtectedRoute>
  )
}
