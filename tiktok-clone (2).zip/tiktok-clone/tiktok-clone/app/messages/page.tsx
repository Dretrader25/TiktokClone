"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Camera, MessageSquare } from "lucide-react"

import { MobileNavbar } from "@/components/mobile-navbar"
import { PageTransition } from "@/components/animated-components"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import InboxContent from "@/components/inbox-content"
import SnapsContent from "@/components/snaps-content"
import { ProtectedRoute } from "@/components/protected-route"

export default function MessagesPage() {
  const [activeTab, setActiveTab] = useState<"inbox" | "snaps">("inbox")

  return (
    <ProtectedRoute>
      <PageTransition>
        <div className="min-h-screen bg-background text-foreground pb-16">
          <div className="sticky top-0 z-20 bg-black border-b border-zinc-800">
            <div className="p-4">
              <h1 className="text-xl font-bold text-center">Messages</h1>
            </div>

            <Tabs
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as "inbox" | "snaps")}
              className="w-full"
            >
              <TabsList className="w-full bg-zinc-900 rounded-none">
                <TabsTrigger value="inbox" className="flex-1 py-3">
                  <div className="flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 mr-2" />
                    <motion.span layoutId="messagesTabContent">Inbox</motion.span>
                  </div>
                </TabsTrigger>
                <TabsTrigger value="snaps" className="flex-1 py-3">
                  <div className="flex items-center justify-center">
                    <Camera className="h-5 w-5 mr-2" />
                    <motion.span layoutId="messagesTabContent">Snaps</motion.span>
                  </div>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "inbox" ? (
              <motion.div
                key="inbox-content"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className="h-[calc(100vh-128px)]"
              >
                <InboxContent />
              </motion.div>
            ) : (
              <motion.div
                key="snaps-content"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="h-[calc(100vh-128px)]"
              >
                <SnapsContent />
              </motion.div>
            )}
          </AnimatePresence>

          <MobileNavbar />
        </div>
      </PageTransition>
    </ProtectedRoute>
  )
}
