import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Messages | TikTok Clone",
  description: "View your messages and snaps",
}

export default function MessagesLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}
