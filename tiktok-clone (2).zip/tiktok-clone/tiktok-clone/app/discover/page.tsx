"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Search, TrendingUp, X, ArrowRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MobileNavbar } from "@/components/mobile-navbar"
import { Button } from "@/components/ui/button"
import { PageTransition, SlideUp, AnimatedIcon } from "@/components/animated-components"
import NearbyContent from "@/components/nearby-content"

// Sample trending data
const TRENDING_CATEGORIES = [
  { id: "for-you", name: "For You" },
  { id: "gaming", name: "Gaming" },
  { id: "comedy", name: "Comedy" },
  { id: "fashion", name: "Fashion" },
  { id: "food", name: "Food" },
  { id: "sports", name: "Sports" },
  { id: "music", name: "Music" },
]

const TRENDING_HASHTAGS = [
  { tag: "#dance", count: "2.4B", videos: 12400 },
  { tag: "#fyp", count: "1.8B", videos: 9800 },
  { tag: "#comedy", count: "1.2B", videos: 7600 },
  { tag: "#viral", count: "987M", videos: 5400 },
  { tag: "#trending", count: "756M", videos: 4200 },
]

const TRENDING_VIDEOS = Array.from({ length: 12 }).map((_, i) => ({
  id: `trend-${i}`,
  thumbnail: `/placeholder.svg?height=200&width=150&query=trending+video+${i}`,
  views: `${Math.floor(Math.random() * 10) + 1}.${Math.floor(Math.random() * 9)}M`,
  creator: `@creator${i}`,
  title: `Trending video #${i + 1}`,
}))

export default function DiscoverPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("for-you")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [selectedHashtag, setSelectedHashtag] = useState<string | null>(null)
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const [activeMainTab, setActiveMainTab] = useState("trending")

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchResults(true)
    }
  }

  // Clear search
  const clearSearch = () => {
    setSearchQuery("")
    setShowSearchResults(false)
    searchInputRef.current?.focus()
  }

  // Handle category selection
  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId)
    // In a real app, you would fetch data for this category
    console.log(`Selected category: ${categoryId}`)
  }

  // Handle hashtag selection
  const handleHashtagSelect = (hashtag: string) => {
    setSelectedHashtag(hashtag)
    // In a real app, you would navigate to hashtag page or show modal
    console.log(`Selected hashtag: ${hashtag}`)
  }

  // Handle video selection
  const handleVideoSelect = (videoId: string) => {
    setSelectedVideo(videoId)
    // In a real app, you would navigate to video page or show modal
    console.log(`Selected video: ${videoId}`)
  }

  // Close hashtag detail view
  const closeHashtagDetail = () => {
    setSelectedHashtag(null)
  }

  // Close video detail view
  const closeVideoDetail = () => {
    setSelectedVideo(null)
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background text-foreground pb-16">
        <div className="p-4">
          <form onSubmit={handleSearch} className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-400" />
            <Input
              ref={searchInputRef}
              className="bg-zinc-900 border-zinc-800 pl-10 pr-10"
              placeholder="Search videos, users, or hashtags"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8"
                onClick={clearSearch}
              >
                <X className="h-4 w-4 text-zinc-400" />
              </Button>
            )}
          </form>

          <AnimatePresence mode="wait">
            {showSearchResults ? (
              <motion.div
                key="search-results"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold">Search Results</h2>
                  <Button variant="ghost" size="sm" onClick={clearSearch}>
                    Clear
                  </Button>
                </div>

                <div className="space-y-4">
                  <p className="text-zinc-400">Results for "{searchQuery}"</p>

                  {/* Sample search results */}
                  <div className="space-y-2">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <motion.div
                        key={i}
                        whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                        className="flex items-center p-3 rounded-lg cursor-pointer"
                        onClick={() => console.log(`Clicked search result ${i}`)}
                      >
                        <div className="h-12 w-12 bg-zinc-800 rounded-md overflow-hidden mr-3">
                          <img
                            src={`/search-result-interface.png?height=48&width=48&query=search+result+${i}`}
                            alt={`Search result ${i + 1}`}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium">
                            {searchQuery} result {i + 1}
                          </p>
                          <p className="text-xs text-zinc-400">Related to your search</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : selectedHashtag ? (
              <motion.div
                key="hashtag-detail"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <div className="flex items-center mb-4">
                  <Button variant="ghost" size="icon" onClick={closeHashtagDetail} className="mr-2">
                    <ArrowRight className="h-5 w-5 rotate-180" />
                  </Button>
                  <h2 className="text-lg font-bold">{selectedHashtag}</h2>
                </div>

                <div className="mb-4 bg-zinc-900 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <TrendingUp className="h-5 w-5 text-primary mr-2" />
                      <span className="font-medium">Trending</span>
                    </div>
                    <Button variant="outline" size="sm" className="text-xs h-8">
                      Follow
                    </Button>
                  </div>
                  <p className="text-sm text-zinc-400 mb-2">Join the trend with {selectedHashtag} videos</p>
                  <div className="flex justify-between text-xs text-zinc-400">
                    <span>{TRENDING_HASHTAGS.find((h) => h.tag === selectedHashtag)?.count || "1M+"} views</span>
                    <span>{TRENDING_HASHTAGS.find((h) => h.tag === selectedHashtag)?.videos || "5000"}+ videos</span>
                  </div>
                </div>

                <h3 className="font-medium mb-2">Popular Videos</h3>
                <div className="grid grid-cols-3 gap-1">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="aspect-[3/4] bg-zinc-900 relative rounded-md overflow-hidden"
                      onClick={() => handleVideoSelect(`hashtag-video-${i}`)}
                    >
                      <img
                        src={`/abstract-geometric-shapes.png?height=150&width=100&query=${selectedHashtag}+video+${i}`}
                        alt={`${selectedHashtag} video ${i + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-1 right-1 bg-black/60 px-1 py-0.5 rounded text-xs">
                        {Math.floor(Math.random() * 10) + 1}.{Math.floor(Math.random() * 9)}M
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ) : selectedVideo ? (
              <motion.div
                key="video-detail"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <div className="flex items-center mb-4">
                  <Button variant="ghost" size="icon" onClick={closeVideoDetail} className="mr-2">
                    <ArrowRight className="h-5 w-5 rotate-180" />
                  </Button>
                  <h2 className="text-lg font-bold truncate">
                    {TRENDING_VIDEOS.find((v) => v.id === selectedVideo)?.title || "Video Details"}
                  </h2>
                </div>

                <div className="aspect-[9/16] bg-zinc-900 rounded-lg overflow-hidden mb-4">
                  <img
                    src={TRENDING_VIDEOS.find((v) => v.id === selectedVideo)?.thumbnail || "/placeholder.svg"}
                    alt="Video preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Button variant="outline" size="icon" className="rounded-full bg-black/50 backdrop-blur-sm">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-play"
                      >
                        <polygon points="5 3 19 12 5 21 5 3"></polygon>
                      </svg>
                    </Button>
                  </div>
                </div>

                <div className="flex items-center mb-4">
                  <div className="h-10 w-10 rounded-full overflow-hidden mr-3">
                    <img src="/diverse-avatars.png" alt="Creator" className="h-full w-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">
                      {TRENDING_VIDEOS.find((v) => v.id === selectedVideo)?.creator || "@creator"}
                    </p>
                    <p className="text-xs text-zinc-400">Original creator</p>
                  </div>
                  <Button size="sm" className="bg-primary hover:bg-primary/90">
                    Follow
                  </Button>
                </div>

                <div className="flex gap-2 mb-4">
                  <Button variant="outline" size="sm" className="flex-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-heart mr-1"
                    >
                      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
                    </svg>
                    Like
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-message-circle mr-1"
                    >
                      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                    </svg>
                    Comment
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-share-2 mr-1"
                    >
                      <circle cx="18" cy="5" r="3"></circle>
                      <circle cx="6" cy="12" r="3"></circle>
                      <circle cx="18" cy="19" r="3"></circle>
                      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                    </svg>
                    Share
                  </Button>
                </div>

                <div className="bg-zinc-900 rounded-lg p-3">
                  <p className="text-sm mb-2">
                    {TRENDING_VIDEOS.find((v) => v.id === selectedVideo)?.title || "Trending video"} #trending #viral
                  </p>
                  <p className="text-xs text-zinc-400">
                    {TRENDING_VIDEOS.find((v) => v.id === selectedVideo)?.views || "1M"} views
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div key="discover-main">
                <Tabs defaultValue="trending" value={activeMainTab} onValueChange={setActiveMainTab} className="w-full">
                  <TabsList className="w-full bg-zinc-900 mb-4">
                    <TabsTrigger value="trending" className="flex-1">
                      <motion.span layoutId="discoverTabContent">Trending</motion.span>
                    </TabsTrigger>
                    <TabsTrigger value="live" className="flex-1">
                      <motion.span layoutId="discoverTabContent">Live</motion.span>
                    </TabsTrigger>
                    <TabsTrigger value="nearby" className="flex-1">
                      <motion.span layoutId="discoverTabContent">Nearby</motion.span>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="trending">
                    <SlideUp>
                      <div className="mb-6 overflow-x-auto">
                        <div className="flex gap-2 pb-2">
                          {TRENDING_CATEGORIES.map((category) => (
                            <motion.button
                              key={category.id}
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => handleCategorySelect(category.id)}
                              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm ${
                                selectedCategory === category.id ? "bg-primary text-white" : "bg-zinc-900 text-zinc-300"
                              }`}
                            >
                              {category.name}
                            </motion.button>
                          ))}
                        </div>
                      </div>
                    </SlideUp>

                    <SlideUp delay={0.1}>
                      <div className="mb-8">
                        <div className="flex justify-between items-center mb-4">
                          <h2 className="text-lg font-bold">Trending Hashtags</h2>
                          <Button variant="ghost" size="sm" className="text-xs text-zinc-400">
                            See all
                          </Button>
                        </div>
                        <div className="space-y-3">
                          {TRENDING_HASHTAGS.map((hashtag) => (
                            <motion.div
                              key={hashtag.tag}
                              whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                              className="flex justify-between items-center p-3 rounded-lg cursor-pointer"
                              onClick={() => handleHashtagSelect(hashtag.tag)}
                            >
                              <div className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center mr-3">
                                  <TrendingUp className="h-4 w-4" />
                                </div>
                                <div className="font-medium">{hashtag.tag}</div>
                              </div>
                              <div className="flex items-center">
                                <div className="text-sm text-zinc-400 mr-2">{hashtag.count} views</div>
                                <AnimatedIcon>
                                  <ArrowRight className="h-4 w-4 text-zinc-400" />
                                </AnimatedIcon>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </SlideUp>

                    <SlideUp delay={0.2}>
                      <div>
                        <div className="flex justify-between items-center mb-4">
                          <h2 className="text-lg font-bold">Trending Now</h2>
                          <Button variant="ghost" size="sm" className="text-xs text-zinc-400">
                            Refresh
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          {TRENDING_VIDEOS.slice(0, 6).map((video) => (
                            <motion.div
                              key={video.id}
                              whileHover={{ scale: 1.03 }}
                              whileTap={{ scale: 0.97 }}
                              className="relative cursor-pointer"
                              onClick={() => handleVideoSelect(video.id)}
                            >
                              <div className="aspect-[3/4] rounded-md overflow-hidden">
                                <img
                                  src={video.thumbnail || "/placeholder.svg"}
                                  alt="Trending video"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="absolute bottom-2 right-2 bg-black/60 px-2 py-1 rounded text-xs">
                                {video.views}
                              </div>
                              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 rounded-b-md">
                                <p className="text-xs font-medium truncate">{video.creator}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </SlideUp>
                  </TabsContent>

                  <TabsContent value="live">
                    <SlideUp>
                      <div className="mb-4">
                        <h2 className="text-lg font-bold mb-4">Live Now</h2>
                        <div className="grid grid-cols-2 gap-2">
                          {Array.from({ length: 4 }).map((_, i) => (
                            <motion.div
                              key={i}
                              whileHover={{ scale: 1.03 }}
                              whileTap={{ scale: 0.97 }}
                              className="relative cursor-pointer"
                              onClick={() => console.log(`Clicked live stream ${i}`)}
                            >
                              <div className="aspect-[3/4] rounded-md overflow-hidden">
                                <img
                                  src={`/digital-live-event.png?height=200&width=150&query=live+stream+${i}`}
                                  alt={`Live stream ${i + 1}`}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="absolute top-2 left-2 bg-red-500 px-2 py-0.5 rounded text-xs font-medium flex items-center">
                                <span className="h-2 w-2 bg-white rounded-full mr-1"></span>
                                LIVE
                              </div>
                              <div className="absolute bottom-2 right-2 bg-black/60 px-2 py-1 rounded text-xs">
                                {Math.floor(Math.random() * 10) + 1}K viewers
                              </div>
                              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 rounded-b-md">
                                <p className="text-xs font-medium truncate">@livestreamer{i}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-4">
                          <h2 className="text-lg font-bold">Upcoming Lives</h2>
                          <Button variant="ghost" size="sm" className="text-xs text-zinc-400">
                            See all
                          </Button>
                        </div>
                        <div className="space-y-3">
                          {Array.from({ length: 3 }).map((_, i) => (
                            <motion.div
                              key={i}
                              whileHover={{ backgroundColor: "rgba(39, 39, 42, 0.3)" }}
                              className="flex items-center p-3 rounded-lg cursor-pointer"
                              onClick={() => console.log(`Clicked upcoming live ${i}`)}
                            >
                              <div className="h-12 w-12 rounded-md overflow-hidden mr-3">
                                <img
                                  src={`/vibrant-stage-lights.png?height=48&width=48&query=upcoming+live+${i}`}
                                  alt={`Upcoming live ${i + 1}`}
                                  className="h-full w-full object-cover"
                                />
                              </div>
                              <div className="flex-1">
                                <p className="font-medium">Live Event {i + 1}</p>
                                <p className="text-xs text-zinc-400">Starting in {i + 1} hour(s)</p>
                              </div>
                              <Button size="sm" variant="outline" className="text-xs h-8">
                                Remind
                              </Button>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </SlideUp>
                  </TabsContent>

                  <TabsContent value="nearby">
                    <NearbyContent />
                  </TabsContent>
                </Tabs>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <MobileNavbar />
      </div>
    </PageTransition>
  )
}
