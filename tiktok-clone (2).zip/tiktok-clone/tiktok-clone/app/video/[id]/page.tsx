"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Heart, MessageCircle, Share2, Music2 } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { MobileNavbar } from "@/components/mobile-navbar"
import { PageTransition } from "@/components/animated-components"
import VideoPlayer from "@/components/video-player"
import { CommentsModal } from "@/components/comments-modal"
import { ShareModal } from "@/components/share-modal"
import { useNotification } from "@/contexts/notification-context"

// Mock video data - in a real app, this would come from your database
const MOCK_VIDEOS = {
  v1: {
    id: "v1",
    videoUrl: "/vibrant-street-dance.png",
    username: "@dancequeen",
    description: "New dance trend! Who's trying this? #dance #trending",
    likes: 8743,
    comments: 124,
    shares: 342,
    userAvatar: "/diverse-woman-avatars.png",
    audio: "Trending Song - Artist Name",
    userId: "user1",
  },
  v2: {
    id: "v2",
    videoUrl: "/joyful-street-dancer.png",
    username: "@dancequeen",
    description: "Morning routine 💃 #dance #morning",
    likes: 4200,
    comments: 87,
    shares: 156,
    userAvatar: "/diverse-woman-avatars.png",
    audio: "Morning Vibes - DJ Mix",
    userId: "user1",
  },
  v3: {
    id: "v3",
    videoUrl: "/vibrant-city-busker.png",
    username: "@dancequeen",
    description: "Street performance in NYC! #dance #nyc",
    likes: 2100,
    comments: 45,
    shares: 78,
    userAvatar: "/diverse-woman-avatars.png",
    audio: "Street Beats - Live",
    userId: "user1",
  },
  v4: {
    id: "v4",
    videoUrl: "/joyful-street-dancer.png",
    username: "@creativecoder",
    description: "Check out this cool effect! #coding #effects",
    likes: 1243,
    comments: 32,
    shares: 17,
    userAvatar: "/diverse-avatars.png",
    audio: "Original Sound - creativecoder",
    userId: "user2",
  },
  v5: {
    id: "v5",
    videoUrl: "/squirrel-nut-heist.png",
    username: "@creativecoder",
    description: "When your code compiles on the first try 😮 #coding #miracle",
    likes: 950,
    comments: 28,
    shares: 12,
    userAvatar: "/diverse-avatars.png",
    audio: "Surprise Sound - meme",
    userId: "user2",
  },
  v6: {
    id: "v6",
    videoUrl: "/squirrel-nut-heist.png",
    username: "@funnyguy",
    description: "When your code finally works 😂 #programming #humor",
    likes: 8900,
    comments: 340,
    shares: 560,
    userAvatar: "/diverse-man-portrait.png",
    audio: "Funny Sound Effect - meme",
    userId: "user3",
  },
  v7: {
    id: "v7",
    videoUrl: "/comedic-stage-mishap.png",
    username: "@funnyguy",
    description: "Oops! 🤣 #fail #funny",
    likes: 5400,
    comments: 210,
    shares: 320,
    userAvatar: "/diverse-man-portrait.png",
    audio: "Comedy Sound - remix",
    userId: "user3",
  },
  v8: {
    id: "v8",
    videoUrl: "/vibrant-street-dance.png",
    username: "@funnyguy",
    description: "Trying to dance like @dancequeen 😅 #dance #attempt",
    likes: 3200,
    comments: 150,
    shares: 95,
    userAvatar: "/diverse-man-portrait.png",
    audio: "Trending Song - Artist Name",
    userId: "user3",
  },
}

export default function VideoPage() {
  const params = useParams()
  const router = useRouter()
  const { showNotification } = useNotification()
  const [video, setVideo] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isLiked, setIsLiked] = useState(false)
  const [showCommentsModal, setShowCommentsModal] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)

  useEffect(() => {
    const videoId = params.id as string

    // In a real app, you would fetch video data from your database
    // For now, we'll use mock data
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      const videoData = MOCK_VIDEOS[videoId as keyof typeof MOCK_VIDEOS]
      if (videoData) {
        setVideo(videoData)
      } else {
        showNotification("error", "Video not found")
        router.push("/")
      }
      setIsLoading(false)
    }, 500)
  }, [params.id, router, showNotification])

  const handleLike = () => {
    setIsLiked(!isLiked)
    showNotification("success", isLiked ? "Removed from liked videos" : "Added to liked videos")
  }

  const handleComment = () => {
    setShowCommentsModal(true)
  }

  const handleShare = () => {
    setShowShareModal(true)
  }

  const handleProfileClick = (userId: string) => {
    router.push(`/user/${userId}`)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Video not found</h2>
          <Button onClick={() => router.push("/")}>Go Home</Button>
        </div>
      </div>
    )
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background text-foreground pb-16">
        <div className="sticky top-0 z-10 bg-background">
          <div className="flex items-center p-4">
            <Button variant="ghost" size="icon" onClick={() => router.back()}>
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h1 className="text-xl font-bold ml-2">Video</h1>
          </div>
        </div>

        <div className="relative aspect-[9/16] max-h-[70vh] w-full">
          <VideoPlayer src={video.videoUrl} isActive={true} />
        </div>

        <div className="p-4">
          <div className="flex items-center mb-4">
            <div
              className="h-10 w-10 rounded-full overflow-hidden mr-3 cursor-pointer"
              onClick={() => handleProfileClick(video.userId)}
            >
              <img
                src={video.userAvatar || "/placeholder.svg"}
                alt={video.username}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex-1">
              <h2 className="font-bold cursor-pointer" onClick={() => handleProfileClick(video.userId)}>
                {video.username}
              </h2>
              <p className="text-sm text-muted-foreground">{video.description}</p>
            </div>
            <Button size="sm">Follow</Button>
          </div>

          <div className="flex items-center gap-2 mb-4">
            <div className="flex items-center gap-1 bg-muted/50 rounded-full px-3 py-1.5">
              <Music2 className="h-4 w-4" />
              <span className="text-xs">{video.audio}</span>
            </div>
          </div>

          <div className="flex justify-between border-t border-b border-border py-3">
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleLike}>
                <Heart className={`h-5 w-5 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
                <span>{isLiked ? video.likes + 1 : video.likes}</span>
              </Button>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleComment}>
                <MessageCircle className="h-5 w-5" />
                <span>{video.comments}</span>
              </Button>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleShare}>
                <Share2 className="h-5 w-5" />
                <span>{video.shares}</span>
              </Button>
            </div>
          </div>

          <div className="mt-4">
            <h3 className="font-bold mb-2">Related Videos</h3>
            <div className="grid grid-cols-3 gap-2">
              {Object.values(MOCK_VIDEOS)
                .filter((v: any) => v.id !== video.id)
                .slice(0, 6)
                .map((relatedVideo: any) => (
                  <motion.div
                    key={relatedVideo.id}
                    whileHover={{ scale: 1.05 }}
                    className="aspect-[3/4] bg-muted relative overflow-hidden rounded-md cursor-pointer"
                    onClick={() => router.push(`/video/${relatedVideo.id}`)}
                  >
                    <img
                      src={relatedVideo.videoUrl || "/placeholder.svg"}
                      alt={relatedVideo.description}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/60 px-1 py-0.5 rounded text-xs">
                      {relatedVideo.likes} likes
                    </div>
                  </motion.div>
                ))}
            </div>
          </div>
        </div>

        {/* Comments Modal */}
        <CommentsModal isOpen={showCommentsModal} onClose={() => setShowCommentsModal(false)} videoId={video.id} />

        {/* Share Modal */}
        <ShareModal isOpen={showShareModal} onClose={() => setShowShareModal(false)} videoId={video.id} />

        <MobileNavbar />
      </div>
    </PageTransition>
  )
}
