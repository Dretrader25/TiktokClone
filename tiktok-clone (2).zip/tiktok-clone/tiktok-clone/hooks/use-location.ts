"use client"

import { useState, useEffect } from "react"
import LocationService from "@/utils/location-service"

type LocationStatus = "prompt" | "granted" | "denied" | "unavailable"

type Coordinates = {
  latitude: number
  longitude: number
  accuracy?: number
}

export function useLocation() {
  const [status, setStatus] = useState<LocationStatus>("prompt")
  const [location, setLocation] = useState<Coordinates | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const locationService = LocationService.getInstance()

  useEffect(() => {
    // Initialize with current status and location
    setStatus(locationService.getStatus())
    setLocation(locationService.getCurrentLocation())

    // Set up listener for location updates
    const removeListener = locationService.addListener((newLocation, newStatus) => {
      setLocation(newLocation)
      setStatus(newStatus)
    })

    // Clean up listener on unmount
    return () => {
      removeListener()
    }
  }, [])

  const requestPermission = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const newStatus = await locationService.requestPermission()
      setStatus(newStatus)

      if (newStatus === "granted") {
        locationService.startWatchingLocation()
      } else if (newStatus === "denied") {
        setError("Location permission denied. Please enable location services in your browser settings.")
      } else if (newStatus === "unavailable") {
        setError("Location services are not available on this device or browser.")
      }
    } catch (err) {
      setError("An error occurred while requesting location permission.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return {
    status,
    location,
    isLoading,
    error,
    requestPermission,
  }
}
