"use client"

import { useState, useCallback, type ChangeEvent, type FormEvent } from "react"
import { validateForm, type ValidationRules, type ValidationErrors, hasErrors } from "@/lib/form-validation"

export function useForm<T extends Record<string, any>>(
  initialValues: T,
  validationRules?: ValidationRules,
  onSubmit?: (values: T) => void | Promise<void>,
) {
  const [values, setValues] = useState<T>(initialValues)
  const [errors, setErrors] = useState<ValidationErrors>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const validate = useCallback(
    (formValues: T = values): ValidationErrors => {
      if (!validationRules) return {}
      return validateForm(formValues, validationRules)
    },
    [values, validationRules],
  )

  const handleChange = useCallback(
    (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const { name, value, type } = e.target

      // Handle different input types
      let newValue: any = value
      if (type === "checkbox") {
        newValue = (e.target as HTMLInputElement).checked
      } else if (type === "number") {
        newValue = value === "" ? "" : Number(value)
      }

      setValues((prev) => ({ ...prev, [name]: newValue }))

      // Mark field as touched
      if (!touched[name]) {
        setTouched((prev) => ({ ...prev, [name]: true }))
      }

      // Validate on change if the form has been submitted
      if (isSubmitted && validationRules) {
        const newValues = { ...values, [name]: newValue }
        const newErrors = validate(newValues)
        setErrors(newErrors)
      }
    },
    [values, touched, isSubmitted, validationRules, validate],
  )

  const handleBlur = useCallback(
    (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const { name } = e.target

      // Mark field as touched
      if (!touched[name]) {
        setTouched((prev) => ({ ...prev, [name]: true }))
      }

      // Validate on blur
      if (validationRules) {
        const fieldErrors = validateForm(values, { [name]: validationRules[name] })
        setErrors((prev) => ({ ...prev, ...fieldErrors }))
      }
    },
    [values, touched, validationRules],
  )

  const handleSubmit = useCallback(
    async (e: FormEvent) => {
      e.preventDefault()

      setIsSubmitted(true)

      // Validate all fields
      const formErrors = validate()
      setErrors(formErrors)

      // Mark all fields as touched
      const allTouched = Object.keys(values).reduce((acc, key) => ({ ...acc, [key]: true }), {})
      setTouched(allTouched)

      // Don't submit if there are errors
      if (hasErrors(formErrors)) {
        return
      }

      if (onSubmit) {
        setIsSubmitting(true)
        try {
          await onSubmit(values)
        } finally {
          setIsSubmitting(false)
        }
      }
    },
    [values, validate, onSubmit],
  )

  const resetForm = useCallback(() => {
    setValues(initialValues)
    setErrors({})
    setTouched({})
    setIsSubmitted(false)
    setIsSubmitting(false)
  }, [initialValues])

  const setFieldValue = useCallback(
    (name: string, value: any) => {
      setValues((prev) => ({ ...prev, [name]: value }))

      // Validate field if the form has been submitted
      if (isSubmitted && validationRules && validationRules[name]) {
        const newValues = { ...values, [name]: value }
        const fieldErrors = validateForm(newValues, { [name]: validationRules[name] })
        setErrors((prev) => ({ ...prev, ...fieldErrors }))
      }
    },
    [values, isSubmitted, validationRules],
  )

  return {
    values,
    errors,
    touched,
    isSubmitting,
    isSubmitted,
    handleChange,
    handleBlur,
    handleSubmit,
    resetForm,
    setFieldValue,
  }
}
