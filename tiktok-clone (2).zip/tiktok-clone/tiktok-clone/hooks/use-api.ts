"use client"

import { useState, useEffect, useCallback } from "react"
import ApiService, { type ApiOptions, type ApiError } from "@/lib/api-service"

// Update the useApi hook to not require authentication by default
export function useApi<T>(endpoint: string, options: ApiOptions = {}) {
  const [data, setData] = useState<T | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<ApiError | null>(null)

  const fetchData = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      const apiService = ApiService.getInstance()
      const result = await apiService.fetch<T>(endpoint, options)
      setData(result)
      return result
    } catch (err) {
      const apiError = err as ApiError
      setError(apiError)

      // Don't throw authentication errors if authentication is not required
      if (apiError.message === "Authentication required" && !options.requireAuth) {
        console.log("Authentication required but not enforced for:", endpoint)
        setIsLoading(false)
        return null
      }

      throw apiError
    } finally {
      setIsLoading(false)
    }
  }, [endpoint, JSON.stringify(options)])

  useEffect(() => {
    fetchData().catch((err) => {
      // Silently handle authentication errors when not required
      if (err?.message === "Authentication required" && !options.requireAuth) {
        return
      }
      console.error("Error fetching data:", err)
    })
  }, [fetchData])

  const mutate = async () => {
    return fetchData()
  }

  return { data, isLoading, error, mutate }
}

// Update the useMutation hook to not require authentication by default
export function useMutation<T, U = any>(endpoint: string, options: ApiOptions = {}) {
  const [data, setData] = useState<T | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<ApiError | null>(null)

  const mutate = async (body: U) => {
    setIsLoading(true)
    setError(null)

    try {
      const apiService = ApiService.getInstance()
      const result = await apiService.fetch<T>(endpoint, {
        ...options,
        method: options.method || "POST",
        body,
      })
      setData(result)
      return result
    } catch (err) {
      const apiError = err as ApiError
      setError(apiError)
      throw apiError
    } finally {
      setIsLoading(false)
    }
  }

  return { data, isLoading, error, mutate }
}
