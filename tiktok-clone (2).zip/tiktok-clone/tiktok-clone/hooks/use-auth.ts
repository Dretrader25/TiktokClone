"use client"

import { useState, useEffect } from "react"
import AuthService, {
  type User,
  type LoginCredentials,
  type RegisterCredentials,
  DEMO_ACCOUNT,
} from "@/lib/auth-service"
import { getSupabaseClient } from "@/lib/supabase-client"

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isDemoUser, setIsDemoUser] = useState(false)

  useEffect(() => {
    const authService = AuthService.getInstance()
    const supabase = getSupabaseClient()

    // Initialize with current user
    setUser(authService.getUser())
    setIsDemoUser(authService.isDemoUser())

    // Check for Supabase session
    if (supabase) {
      supabase.auth.getSession().then(({ data }) => {
        if (data.session) {
          // If we have a Supabase session but no AuthService user,
          // we can create a mock user for demo purposes
          if (!authService.getUser()) {
            const mockUser = {
              id: data.session.user.id,
              username: data.session.user.email ? `@${data.session.user.email.split("@")[0]}` : "@user",
              email: data.session.user.email || "user@example.com",
              avatar: "/diverse-avatars.png",
              isVerified: false,
            }
            // This is just for demo - in a real app, you'd sync with your backend
            console.log("Using Supabase session user:", mockUser)
          }
        }
        setIsLoading(false)
      })
    } else {
      setIsLoading(false)
    }

    // Listen for auth changes
    const removeListener = authService.addAuthChangeListener((newUser) => {
      setUser(newUser)
      setIsDemoUser(authService.isDemoUser())
    })

    return removeListener
  }, [])

  const login = async (credentials: LoginCredentials) => {
    setIsLoading(true)
    setError(null)

    try {
      const authService = AuthService.getInstance()
      const user = await authService.login(credentials)

      // Check if this is the demo account login
      if (credentials.email === DEMO_ACCOUNT.email && credentials.password === DEMO_ACCOUNT.password) {
        setIsDemoUser(true)
      }

      return user
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Login failed"
      setError(errorMessage)
      throw err
    } finally {
      setIsLoading(false)
    }
  }

  const loginWithDemo = async () => {
    return login({
      email: DEMO_ACCOUNT.email,
      password: DEMO_ACCOUNT.password,
    })
  }

  const register = async (credentials: RegisterCredentials) => {
    setIsLoading(true)
    setError(null)

    try {
      const authService = AuthService.getInstance()
      const user = await authService.register(credentials)
      return user
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Registration failed"
      setError(errorMessage)
      throw err
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const authService = AuthService.getInstance()
      await authService.logout()
      setIsDemoUser(false)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Logout failed"
      setError(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    error,
    isDemoUser,
    login,
    loginWithDemo,
    register,
    logout,
  }
}
